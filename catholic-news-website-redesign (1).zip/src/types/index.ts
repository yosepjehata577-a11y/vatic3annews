export type Category = 
  | 'All'
  | 'Vatican'
  | 'Pope'
  | 'Church'
  | 'World'
  | 'Faith'
  | 'Prayer'
  | 'Gospel'
  | 'Catholic Life'
  | 'Culture'
  | 'Analysis';

export interface Article {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  leadParagraph: string;
  content: string[];
  category: Category;
  author: {
    name: string;
    role: string;
    avatar?: string;
  };
  publishedAt: string;
  readTime: string;
  imageUrl: string;
  imageCaption: string;
  imageCredit: string;
  isLeadStory?: boolean;
  isSecondaryLead?: boolean;
  isBreaking?: boolean;
  tags: string[];
  views: number;
}

export interface LiturgicalDay {
  date: string;
  formattedDate: string;
  liturgicalSeason: string;
  seasonColor: 'violet' | 'green' | 'white' | 'red' | 'rose';
  colorName: string;
  feastName: string;
  saintOfTheDay: {
    name: string;
    title: string;
    bio: string;
    patronage: string;
  };
  readings: {
    firstReading: { citation: string; excerpt: string };
    responsorialPsalm: { citation: string; response: string };
    secondReading?: { citation: string; excerpt: string };
    gospel: { citation: string; excerpt: string };
  };
  papalIntention: {
    month: string;
    title: string;
    description: string;
  };
}

export interface RadioBroadcast {
  id: string;
  title: string;
  subtitle: string;
  duration: string;
  audioUrl?: string;
  timeRemaining?: string;
}

export interface TemplateConfig {
  siteTitle: string;
  siteTagline: string;
  primaryColor: string;
  showBreakingTicker: boolean;
  showLiturgicalBar: boolean;
  showAudioPlayer: boolean;
  enableNewsletter: boolean;
  postsPerPage: number;
}
