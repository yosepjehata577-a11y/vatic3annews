// Full Production-Ready Blogger XML Template for Veritas Catholic News
// Compliant with Blogger V3 XML schema, Google SEO standards, and Vatican News editorial aesthetic.

export const BLOGGER_XML_TEMPLATE_CODE = `<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html b:css='false' b:responsive='true' b:version='2' class='v2' expr:dir='data:blog.languageDirection' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
<head>
  <meta charset='utf-8'/>
  <meta content='width=device-width, initial-scale=1, shrink-to-fit=no' name='viewport'/>
  
  <!-- SEO Title Tag -->
  <b:if cond='data:view.isHomepage'>
    <title><data:blog.title/> | Global Catholic News, Vatican Chronicles &amp; Papal Teaching</title>
  <b:else/>
    <b:if cond='data:view.isPost'>
      <title><data:blog.pageName/> - <data:blog.title/></title>
    <b:else/>
      <title><data:blog.pageName/> | <data:blog.title/></title>
    </b:if>
  </b:if>

  <!-- Meta Description and Canonical -->
  <b:if cond='data:blog.metaDescription'>
    <meta expr:content='data:blog.metaDescription' name='description'/>
  <b:else/>
    <meta content='Official international English reporting on the Holy See, Pope Francis, global Catholic dioceses, liturgical teachings, and world humanitarian missions.' name='description'/>
  </b:if>
  <link expr:href='data:blog.canonicalUrl' rel='canonical'/>

  <!-- Open Graph & Social Cards -->
  <meta expr:content='data:blog.title' property='og:site_name'/>
  <b:if cond='data:view.isPost'>
    <meta content='article' property='og:type'/>
    <meta expr:content='data:blog.pageName' property='og:title'/>
    <meta expr:content='data:blog.canonicalUrl' property='og:url'/>
    <b:if cond='data:blog.postImageUrl'>
      <meta expr:content='data:blog.postImageUrl' property='og:image'/>
    </b:if>
  <b:else/>
    <meta content='website' property='og:type'/>
    <meta expr:content='data:blog.title' property='og:title'/>
    <meta expr:content='data:blog.canonicalHomepageUrl' property='og:url'/>
  </b:if>

  <!-- Google Web Fonts for Editorial Authority -->
  <link rel='preconnect' href='https://fonts.googleapis.com'/>
  <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin='anonymous'/>
  <link href='https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&amp;family=EB+Garamond:ital,wght@0,400..700;1,400..700&amp;family=Inter:wght@300;400;500;600;700&amp;family=Playfair+Display:ital,wght@0,600;0,700;0,900;1,400;1,600&amp;display=swap' rel='stylesheet'/>

  <b:skin><![CDATA[
  /* ==========================================================================
     VERITAS CATHOLIC NEWS - THEME STYLESHEET
     Inspired by Vatican News (vaticannews.va)
     Palette: Vatican Burgundy (#7B1113), Papal Gold (#C5A059), Charcoal (#1A1A1A), Warm White (#FAF9F6)
     ========================================================================== */

  :root {
    --primary: #7B1113;
    --primary-dark: #580C0E;
    --primary-light: #9B1B1E;
    --accent: #C5A059;
    --accent-light: #E8D39E;
    --text-main: #1A1A1A;
    --text-muted: #57534E;
    --bg-page: #FAF9F6;
    --bg-card: #FFFFFF;
    --border: #E7E3DC;
    --font-serif: 'Playfair Display', 'EB Garamond', Georgia, serif;
    --font-serif-reading: 'EB Garamond', Georgia, 'Times New Roman', serif;
    --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --font-masthead: 'Cinzel', 'Playfair Display', Georgia, serif;
  }

  /* Reset & Base */
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background-color: var(--bg-page);
    color: var(--text-main);
    font-family: var(--font-sans);
    line-height: 1.6;
    font-size: 16px;
    -webkit-font-smoothing: antialiased;
  }
  a { color: inherit; text-decoration: none; transition: color 0.15s ease; }
  a:hover { color: var(--primary); }
  img { max-width: 100%; height: auto; display: block; }

  /* Container */
  .v-container {
    width: 100%;
    max-width: 1240px;
    margin: 0 auto;
    padding: 0 16px;
  }

  /* Utility Top Bar */
  .v-topbar {
    background-color: var(--primary-dark);
    color: #F5F5F4;
    font-size: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    padding: 6px 0;
  }
  .v-topbar-inner {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
  }
  .v-topbar-date {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .v-liturgical-badge {
    background-color: rgba(197, 160, 89, 0.2);
    color: var(--accent-light);
    border: 1px solid var(--accent);
    padding: 2px 8px;
    border-radius: 2px;
    font-weight: 500;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  .v-topbar-links {
    display: flex;
    align-items: center;
    gap: 16px;
  }

  /* Masthead Header */
  .v-header {
    background-color: #FFFFFF;
    border-bottom: 2px solid var(--border);
    padding: 24px 0 16px;
  }
  .v-masthead {
    text-align: center;
    margin-bottom: 16px;
  }
  .v-emblem-seal {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background-color: var(--primary);
    color: #FFFFFF;
    margin-bottom: 8px;
    box-shadow: 0 2px 6px rgba(123, 17, 19, 0.25);
  }
  .v-masthead h1 {
    font-family: var(--font-masthead);
    font-size: 38px;
    font-weight: 800;
    letter-spacing: 2.5px;
    color: var(--primary-dark);
    text-transform: uppercase;
    line-height: 1.1;
  }
  .v-masthead h1 a { color: var(--primary-dark); }
  .v-tagline {
    font-family: var(--font-serif-reading);
    font-size: 15px;
    font-style: italic;
    color: var(--text-muted);
    letter-spacing: 0.5px;
    margin-top: 4px;
  }

  /* Navigation Bar */
  .v-navbar {
    background-color: var(--primary);
    border-top: 1px solid var(--primary-light);
    position: sticky;
    top: 0;
    z-index: 100;
    box-shadow: 0 2px 8px rgba(0,0,0,0.12);
  }
  .v-nav-inner {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .v-nav-menu {
    display: flex;
    list-style: none;
    overflow-x: auto;
    scrollbar-width: none;
  }
  .v-nav-menu::-webkit-scrollbar { display: none; }
  .v-nav-menu li a {
    display: block;
    color: #FFFFFF;
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 13px 14px;
    white-space: nowrap;
    border-bottom: 3px solid transparent;
    transition: background 0.15s, border-color 0.15s;
  }
  .v-nav-menu li a:hover,
  .v-nav-menu li a.active {
    background-color: var(--primary-dark);
    border-bottom-color: var(--accent);
  }
  .v-nav-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    padding-left: 12px;
  }
  .v-nav-btn {
    background: transparent;
    border: none;
    color: #FFFFFF;
    cursor: pointer;
    padding: 8px;
    border-radius: 4px;
  }
  .v-nav-btn:hover { background: rgba(255,255,255,0.15); }

  /* Breaking Ticker */
  .v-ticker {
    background-color: #FFFFFF;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    font-size: 13px;
    overflow: hidden;
  }
  .v-ticker-label {
    background-color: var(--primary);
    color: #FFFFFF;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 8px 16px;
    display: flex;
    align-items: center;
    gap: 6px;
    flex-shrink: 0;
  }
  .v-ticker-label::after {
    content: '';
    display: inline-block;
    width: 6px;
    height: 6px;
    background: #FFF;
    border-radius: 50%;
  }
  .v-ticker-content {
    padding: 0 16px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-main);
    font-weight: 500;
  }

  /* Main Layout */
  .v-main-content {
    padding: 32px 0 48px;
  }
  .v-grid-layout {
    display: grid;
    grid-template-columns: 1fr 340px;
    gap: 36px;
  }

  /* Lead Editorial Story (Homepage) */
  .v-lead-story {
    background: #FFFFFF;
    border: 1px solid var(--border);
    border-top: 4px solid var(--primary);
    margin-bottom: 32px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  }
  .v-lead-img-wrap {
    position: relative;
    aspect-ratio: 16/9;
    background: #eee;
    overflow: hidden;
  }
  .v-lead-img-wrap img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.4s ease;
  }
  .v-lead-story:hover .v-lead-img-wrap img {
    transform: scale(1.02);
  }
  .v-lead-body {
    padding: 24px;
  }
  .v-category-tag {
    display: inline-block;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--primary);
    background: rgba(123, 17, 19, 0.08);
    padding: 2px 8px;
    margin-bottom: 8px;
    border-radius: 2px;
  }
  .v-lead-title {
    font-family: var(--font-serif);
    font-size: 28px;
    line-height: 1.25;
    font-weight: 700;
    margin-bottom: 12px;
    color: #1A1A1A;
  }
  .v-lead-title a:hover { color: var(--primary); }
  .v-lead-summary {
    font-family: var(--font-serif-reading);
    font-size: 17px;
    color: var(--text-muted);
    line-height: 1.6;
    margin-bottom: 16px;
  }
  .v-post-meta {
    font-size: 12px;
    color: #78716C;
    display: flex;
    align-items: center;
    gap: 12px;
  }

  /* Secondary Editorial Grid */
  .v-secondary-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin-bottom: 36px;
  }
  .v-card {
    background: #FFFFFF;
    border: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    transition: box-shadow 0.2s ease;
  }
  .v-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  }
  .v-card-img-wrap {
    aspect-ratio: 16/10;
    background: #F0ECE1;
    overflow: hidden;
  }
  .v-card-img-wrap img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .v-card-body {
    padding: 16px;
    display: flex;
    flex-direction: column;
    flex-grow: 1;
  }
  .v-card-title {
    font-family: var(--font-serif);
    font-size: 18px;
    font-weight: 700;
    line-height: 1.35;
    margin: 6px 0 8px;
  }
  .v-card-snippet {
    font-size: 14px;
    color: var(--text-muted);
    line-height: 1.5;
    margin-bottom: 12px;
    flex-grow: 1;
  }

  /* Section Header */
  .v-section-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 2px solid var(--primary);
    padding-bottom: 8px;
    margin-bottom: 20px;
  }
  .v-section-title {
    font-family: var(--font-serif);
    font-size: 20px;
    font-weight: 700;
    color: var(--primary);
    text-transform: uppercase;
    letter-spacing: 0.8px;
  }

  /* Article Details (Single Post View) */
  .v-article-view {
    background: #FFFFFF;
    border: 1px solid var(--border);
    padding: 36px;
  }
  .v-article-breadcrumb {
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: var(--text-muted);
    margin-bottom: 16px;
  }
  .v-article-headline {
    font-family: var(--font-serif);
    font-size: 36px;
    line-height: 1.2;
    font-weight: 700;
    color: #111827;
    margin-bottom: 12px;
  }
  .v-article-subhead {
    font-family: var(--font-serif-reading);
    font-size: 20px;
    line-height: 1.5;
    color: #4B5563;
    margin-bottom: 20px;
    border-left: 3px solid var(--accent);
    padding-left: 14px;
    font-style: italic;
  }
  .v-article-byline {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 0;
    border-top: 1px solid var(--border);
    border-bottom: 1px solid var(--border);
    margin-bottom: 24px;
    font-size: 13px;
    color: #6B7280;
  }
  .v-article-featured-img {
    margin-bottom: 24px;
  }
  .v-caption {
    font-size: 13px;
    color: #6B7280;
    padding: 8px 0;
    border-bottom: 1px solid var(--border);
  }
  .v-article-body {
    font-family: var(--font-serif-reading);
    font-size: 19px;
    line-height: 1.8;
    color: #1F2937;
  }
  .v-article-body p {
    margin-bottom: 20px;
  }
  .v-article-body blockquote {
    border-left: 4px solid var(--primary);
    padding: 12px 20px;
    margin: 24px 0;
    font-style: italic;
    font-size: 20px;
    color: var(--primary-dark);
    background: #FAF7F2;
  }

  /* Share Buttons */
  .v-share-bar {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 32px 0 20px;
    padding-top: 16px;
    border-top: 1px solid var(--border);
  }
  .v-share-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border: 1px solid var(--border);
    background: #FAFAFA;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 600;
  }
  .v-share-btn:hover { background: #F3F4F6; }

  /* Sidebar Widgets */
  .v-sidebar-widget {
    background: #FFFFFF;
    border: 1px solid var(--border);
    margin-bottom: 28px;
    padding: 20px;
  }
  .v-widget-title {
    font-family: var(--font-serif);
    font-size: 17px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: var(--primary);
    border-bottom: 2px solid var(--accent);
    padding-bottom: 6px;
    margin-bottom: 16px;
  }

  /* Liturgical Sidebar Box */
  .v-liturgy-box {
    background: linear-gradient(135deg, #FAF7F2 0%, #FFFFFF 100%);
    border: 1px solid var(--accent-light);
    border-left: 4px solid var(--accent);
    padding: 16px;
  }
  .v-liturgy-season {
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    color: var(--primary);
    margin-bottom: 4px;
  }
  .v-liturgy-saint {
    font-size: 15px;
    font-weight: 700;
    margin-bottom: 6px;
  }
  .v-liturgy-readings {
    font-size: 13px;
    color: var(--text-muted);
    line-height: 1.4;
  }

  /* Footer */
  .v-footer {
    background-color: #171513;
    color: #D6D3D1;
    border-top: 4px solid var(--primary);
    padding: 48px 0 24px;
    font-size: 14px;
  }
  .v-footer-grid {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr;
    gap: 32px;
    margin-bottom: 36px;
  }
  .v-footer-brand h2 {
    font-family: var(--font-masthead);
    font-size: 22px;
    color: #FFFFFF;
    margin-bottom: 8px;
    letter-spacing: 1px;
  }
  .v-footer-col h3 {
    font-family: var(--font-serif);
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--accent);
    margin-bottom: 14px;
  }
  .v-footer-col ul { list-style: none; }
  .v-footer-col ul li { margin-bottom: 8px; }
  .v-footer-col ul li a { color: #A8A29E; }
  .v-footer-col ul li a:hover { color: #FFFFFF; }
  .v-footer-bottom {
    border-top: 1px solid #292524;
    padding-top: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
    color: #78716C;
  }

  /* Responsive Media Queries */
  @media (max-width: 991px) {
    .v-grid-layout { grid-template-columns: 1fr; }
    .v-secondary-grid { grid-template-columns: 1fr; }
    .v-footer-grid { grid-template-columns: 1fr 1fr; }
    .v-masthead h1 { font-size: 28px; }
    .v-article-headline { font-size: 28px; }
  }
  @media (max-width: 600px) {
    .v-footer-grid { grid-template-columns: 1fr; }
    .v-article-view { padding: 20px 14px; }
    .v-lead-title { font-size: 22px; }
  }
  ]]></b:skin>

  <b:template-skin><![CDATA[
  /* Responsive viewport definitions and widget wrappers */
  .widget { margin-bottom: 24px; }
  .status-msg-wrap { margin: 20px 0; }
  ]]></b:template-skin>
</head>

<body>
  <!-- 1. Utility Top Bar -->
  <div class='v-topbar'>
    <div class='v-container v-topbar-inner'>
      <div class='v-topbar-date'>
        <span>Vatican City &amp; Global Catholic News</span>
        <span class='v-liturgical-badge'>Ordinary Jubilee Year</span>
      </div>
      <div class='v-topbar-links'>
        <a expr:href='data:blog.canonicalHomepageUrl + "p/vatican-radio.html"'>Vatican Radio Broadcast</a>
        <span>&#8226;</span>
        <a expr:href='data:blog.canonicalHomepageUrl + "p/liturgical-calendar.html"'>Daily Mass Readings</a>
        <span>&#8226;</span>
        <a expr:href='data:blog.canonicalHomepageUrl + "p/pope-intentions.html"'>Pope&#39;s Prayer Intentions</a>
      </div>
    </div>
  </div>

  <!-- 2. Masthead Header Section -->
  <header class='v-header' role='banner'>
    <div class='v-container'>
      <b:section id='header-section' maxwidgets='1' name='Header Masthead' showaddelement='no'>
        <b:widget id='Header1' locked='true' title='Veritas Catholic News' type='Header' version='2'>
          <b:includable id='main'>
            <div class='v-masthead'>
              <div class='v-emblem-seal'>
                <!-- Catholic Cross Emblem SVG -->
                <svg fill='currentColor' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'>
                  <path d='M10 2v6H4v4h6v10h4V12h6V8h-6V2h-4z'/>
                </svg>
              </div>
              <h1>
                <a expr:href='data:blog.canonicalHomepageUrl'>
                  <b:if cond='data:title'><data:title/><b:else/>VERITAS CATHOLIC NEWS</b:if>
                </a>
              </h1>
              <p class='v-tagline'>
                <b:if cond='data:description'><data:description/><b:else/>International Voice of the Catholic Church &#8226; Truth in Charity</b:if>
              </p>
            </div>
          </b:includable>
        </b:widget>
      </b:section>
    </div>
  </header>

  <!-- 3. Navigation Bar (Vatican News Categories) -->
  <nav class='v-navbar' role='navigation'>
    <div class='v-container v-nav-inner'>
      <ul class='v-nav-menu' id='main-nav'>
        <li><a expr:href='data:blog.canonicalHomepageUrl'>Home</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Vatican"'>Vatican</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Pope"'>Pope</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Church"'>Church</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/World"'>World</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Faith"'>Faith</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Prayer"'>Prayer</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Gospel"'>Gospel</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Catholic%20Life"'>Catholic Life</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Culture"'>Culture</a></li>
        <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Analysis"'>Analysis</a></li>
      </ul>
      <div class='v-nav-actions'>
        <!-- Search Trigger Icon -->
        <a class='v-nav-btn' expr:href='data:blog.canonicalHomepageUrl + "?q="' title='Search Articles'>
          <svg fill='none' height='18' stroke='currentColor' stroke-width='2' viewBox='0 0 24 24' width='18' xmlns='http://www.w3.org/2000/svg'>
            <circle cx='11' cy='11' r='8'/>
            <line x1='21' x2='16.65' y1='21' y2='16.65'/>
          </svg>
        </a>
      </div>
    </div>
  </nav>

  <!-- 4. Breaking News Ticker -->
  <div class='v-ticker'>
    <div class='v-container' style='display:flex; align-items:center;'>
      <div class='v-ticker-label'>Breaking</div>
      <div class='v-ticker-content' id='breaking-ticker-text'>
        Pope Francis appeals for humanitarian corridors and lasting peace in Jubilee address to diplomatic corps.
      </div>
    </div>
  </div>

  <!-- 5. Main Content Area & Sidebar Grid -->
  <main class='v-main-content' role='main'>
    <div class='v-container'>
      <div class='v-grid-layout'>
        
        <!-- Posts Column -->
        <div class='v-posts-column'>
          <b:section id='main' name='Main Editorial Content' showaddelement='no'>
            <b:widget id='Blog1' locked='true' title='Blog Posts' type='Blog' version='2'>
              <b:includable id='main' var='top'>
                <!-- Index / Homepage Layout -->
                <b:if cond='data:view.isMultipleItems'>
                  <div class='v-section-heading'>
                    <h2 class='v-section-title'>
                      <b:if cond='data:view.isLabelSearch'>
                        Category: <data:view.search.label/>
                      <b:else/>
                        Featured &amp; Latest Stories
                      </b:if>
                    </h2>
                  </div>

                  <b:loop index='i' values='data:posts' var='post'>
                    <!-- Lead Story (First post on homepage) -->
                    <b:if cond='data:i == 0 and data:view.isHomepage'>
                      <article class='v-lead-story' itemscope='itemscope' itemtype='https://schema.org/NewsArticle'>
                        <b:if cond='data:post.featuredImage or data:post.firstImageUrl'>
                          <div class='v-lead-img-wrap'>
                            <a expr:href='data:post.url'>
                              <img alt='Article Image' expr:src='data:post.featuredImage ?: data:post.firstImageUrl' itemprop='image'/>
                            </a>
                          </div>
                        </b:if>
                        <div class='v-lead-body'>
                          <b:if cond='data:post.labels'>
                            <span class='v-category-tag'><data:post.labels.first.name/></span>
                          </b:if>
                          <h2 class='v-lead-title' itemprop='headline'>
                            <a expr:href='data:post.url'><data:post.title/></a>
                          </h2>
                          <div class='v-lead-summary' itemprop='description'>
                            <data:post.snippet/>
                          </div>
                          <div class='v-post-meta'>
                            <span itemprop='author'><data:post.author.name/></span>
                            <span>&#8226;</span>
                            <time expr:datetime='data:post.date.iso8601' itemprop='datePublished'><data:post.date/></time>
                          </div>
                        </div>
                      </article>
                    <b:else/>
                      <!-- Regular Story Cards -->
                      <article class='v-card' style='margin-bottom:20px;' itemscope='itemscope' itemtype='https://schema.org/NewsArticle'>
                        <div style='display:flex; flex-direction:row; gap:16px; padding:16px; align-items:flex-start;'>
                          <b:if cond='data:post.featuredImage or data:post.firstImageUrl'>
                            <div style='width:160px; height:110px; flex-shrink:0; background:#eee; overflow:hidden;'>
                              <a expr:href='data:post.url'>
                                <img alt='Thumbnail' expr:src='data:post.featuredImage ?: data:post.firstImageUrl' style='width:100%; height:100%; object-fit:cover;'/>
                              </a>
                            </div>
                          </b:if>
                          <div style='flex-grow:1;'>
                            <b:if cond='data:post.labels'>
                              <span class='v-category-tag'><data:post.labels.first.name/></span>
                            </b:if>
                            <h3 class='v-card-title' itemprop='headline' style='font-size:18px;'>
                              <a expr:href='data:post.url'><data:post.title/></a>
                            </h3>
                            <p class='v-card-snippet'><data:post.snippet/></p>
                            <div class='v-post-meta'>
                              <time expr:datetime='data:post.date.iso8601'><data:post.date/></time>
                              <span>&#8226;</span>
                              <span><data:post.author.name/></span>
                            </div>
                          </div>
                        </div>
                      </article>
                    </b:if>
                  </b:loop>

                  <!-- Pagination -->
                  <div style='display:flex; justify-content:space-between; margin-top:28px; padding-top:16px; border-top:1px solid #E5E0D8;'>
                    <b:if cond='data:newerPageUrl'>
                      <a class='v-share-btn' expr:href='data:newerPageUrl'>&#8592; Newer Dispatches</a>
                    </b:if>
                    <b:if cond='data:olderPageUrl'>
                      <a class='v-share-btn' expr:href='data:olderPageUrl' style='margin-left:auto;'>Older Dispatches &#8594;</a>
                    </b:if>
                  </div>
                </b:if>

                <!-- Single Post View -->
                <b:if cond='data:view.isPost'>
                  <b:loop values='data:posts' var='post'>
                    <article class='v-article-view' itemscope='itemscope' itemtype='https://schema.org/NewsArticle'>
                      <div class='v-article-breadcrumb'>
                        <a expr:href='data:blog.canonicalHomepageUrl'>Home</a> &gt; 
                        <b:if cond='data:post.labels'>
                          <a expr:href='data:post.labels.first.url'><data:post.labels.first.name/></a> &gt; 
                        </b:if>
                        <span>Dispatch</span>
                      </div>

                      <h1 class='v-article-headline' itemprop='headline'><data:post.title/></h1>
                      
                      <div class='v-article-byline'>
                        <div>
                          By <strong itemprop='author'><data:post.author.name/></strong> &#8226; 
                          <time expr:datetime='data:post.date.iso8601' itemprop='datePublished'><data:post.date/></time>
                        </div>
                        <div>
                          <b:if cond='data:post.labels'>
                            <span class='v-category-tag'><data:post.labels.first.name/></span>
                          </b:if>
                        </div>
                      </div>

                      <b:if cond='data:post.featuredImage or data:post.firstImageUrl'>
                        <div class='v-article-featured-img'>
                          <img alt='Featured Image' expr:src='data:post.featuredImage ?: data:post.firstImageUrl' itemprop='image' style='width:100%; max-height:520px; object-fit:cover;'/>
                          <p class='v-caption'>Vatican Media &amp; International Catholic Photojournalism.</p>
                        </div>
                      </b:if>

                      <!-- Post Body Content -->
                      <div class='v-article-body' itemprop='articleBody'>
                        <data:post.body/>
                      </div>

                      <!-- Share Bar -->
                      <div class='v-share-bar'>
                        <span style='font-weight:700; font-size:12px; text-transform:uppercase;'>Share Article:</span>
                        <a class='v-share-btn' expr:href='"https://twitter.com/intent/tweet?text=" + data:post.title + "&amp;url=" + data:post.url' target='_blank'>X / Twitter</a>
                        <a class='v-share-btn' expr:href='"https://www.facebook.com/sharer.php?u=" + data:post.url' target='_blank'>Facebook</a>
                        <a class='v-share-btn' expr:href='"mailto:?subject=" + data:post.title + "&amp;body=" + data:post.url'>Email</a>
                      </div>

                      <!-- Labels Tags -->
                      <b:if cond='data:post.labels'>
                        <div style='margin-top:20px; display:flex; flex-wrap:wrap; gap:8px;'>
                          <b:loop values='data:post.labels' var='label'>
                            <a class='v-category-tag' expr:href='data:label.url'>#<data:label.name/></a>
                          </b:loop>
                        </div>
                      </b:if>
                    </article>
                  </b:loop>
                </b:if>
              </b:includable>
            </b:widget>
          </b:section>
        </div>

        <!-- Editorial Sidebar -->
        <aside class='v-sidebar' role='complementary'>
          <b:section id='sidebar' name='Editorial Sidebar' showaddelement='yes'>
            
            <!-- Liturgical Info Widget -->
            <b:widget id='HTML1' locked='false' title='Daily Liturgical Life' type='HTML' version='2'>
              <b:includable id='main'>
                <div class='v-sidebar-widget'>
                  <h3 class='v-widget-title'><data:title/></h3>
                  <div class='v-liturgy-box'>
                    <div class='v-liturgy-season'>Season of Hope &#8226; Ordinary Jubilee</div>
                    <div class='v-liturgy-saint'>Saint of the Day &amp; Lectionary</div>
                    <p class='v-liturgy-readings'>
                      Daily scripture readings, holy saints, and the Pope&#39;s universal monthly prayer intention are refreshed each morning.
                    </p>
                  </div>
                </div>
              </b:includable>
            </b:widget>

            <!-- Popular / Most Read Posts Widget -->
            <b:widget id='PopularPosts1' locked='false' title='Trending Vatican Reports' type='PopularPosts' version='2'>
              <b:includable id='main'>
                <div class='v-sidebar-widget'>
                  <h3 class='v-widget-title'><data:title/></h3>
                  <ul style='list-style:none;'>
                    <b:loop values='data:posts' var='post'>
                      <li style='margin-bottom:12px; padding-bottom:12px; border-bottom:1px solid #EFECE6;'>
                        <a expr:href='data:post.url' style='font-family:var(--font-serif); font-size:15px; font-weight:700; line-height:1.4;'>
                          <data:post.title/>
                        </a>
                      </li>
                    </b:loop>
                  </ul>
                </div>
              </b:includable>
            </b:widget>

            <!-- Topic Labels Widget -->
            <b:widget id='Label1' locked='false' title='News Topics' type='Label' version='2'>
              <b:includable id='main'>
                <div class='v-sidebar-widget'>
                  <h3 class='v-widget-title'><data:title/></h3>
                  <div style='display:flex; flex-wrap:wrap; gap:6px;'>
                    <b:loop values='data:labels' var='label'>
                      <a class='v-category-tag' expr:href='data:label.url'>
                        <data:label.name/> (<data:label.count/>)
                      </a>
                    </b:loop>
                  </div>
                </div>
              </b:includable>
            </b:widget>

            <!-- Newsletter Signup Gadget -->
            <b:widget id='HTML2' locked='false' title='Vatican Briefing Newsletter' type='HTML' version='2'>
              <b:includable id='main'>
                <div class='v-sidebar-widget' style='background:#FAF7F2; border-color:var(--accent);'>
                  <h3 class='v-widget-title' style='color:var(--primary-dark);'>Daily Editorial Briefing</h3>
                  <p style='font-size:13px; color:var(--text-muted); margin-bottom:12px;'>
                    Receive Vatican headlines, papal speeches, and theological commentary straight to your inbox each morning.
                  </p>
                  <form action='https://feedburner.google.com/fb/a/mailverify' method='post' target='popupwindow'>
                    <input name='email' placeholder='Enter your email address' style='width:100%; padding:10px; border:1px solid #CCC; margin-bottom:8px; font-size:13px; border-radius:2px;' type='email'/>
                    <button style='width:100%; background:var(--primary); color:#FFF; border:none; padding:10px; font-weight:700; font-size:13px; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;' type='submit'>
                      Subscribe Free
                    </button>
                  </form>
                </div>
              </b:includable>
            </b:widget>

          </b:section>
        </aside>

      </div>
    </div>
  </main>

  <!-- 6. Professional Footer -->
  <footer class='v-footer' role='contentinfo'>
    <div class='v-container'>
      <div class='v-footer-grid'>
        <!-- Column 1: Publication Overview -->
        <div class='v-footer-brand'>
          <h2>VERITAS CATHOLIC NEWS</h2>
          <p style='color:#A8A29E; line-height:1.6; margin-bottom:14px; font-size:13px;'>
            An independent international Catholic news portal providing fair, faithful, and comprehensive coverage of the Holy See, the universal Church, and human dignity across the globe.
          </p>
          <p style='color:#78716C; font-size:12px;'>
            Editorial Offices: Rome &#8226; Washington &#8226; Nairobi &#8226; Jerusalem
          </p>
        </div>

        <!-- Column 2: Editorial Desk -->
        <div class='v-footer-col'>
          <h3>Editorial Sections</h3>
          <ul>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Vatican"'>Vatican Curia</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Pope"'>Papal Teaching</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Church"'>Universal Church</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Gospel"'>Gospel Reflections</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "search/label/Analysis"'>Moral Analysis</a></li>
          </ul>
        </div>

        <!-- Column 3: Devotion & Media -->
        <div class='v-footer-col'>
          <h3>Media &amp; Liturgy</h3>
          <ul>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/vatican-radio.html"'>Vatican Radio Stream</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/liturgical-calendar.html"'>Daily Mass Readings</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/pope-intentions.html"'>Pope&#39;s Monthly Intention</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/audio-rosary.html"'>Audio Rosary</a></li>
          </ul>
        </div>

        <!-- Column 4: Standards & Legal -->
        <div class='v-footer-col'>
          <h3>Governance</h3>
          <ul>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/about.html"'>About Veritas</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/editorial-policy.html"'>Editorial Standards</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/contact.html"'>Contact Newsroom</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/privacy.html"'>Privacy Policy</a></li>
            <li><a expr:href='data:blog.canonicalHomepageUrl + "p/terms.html"'>Terms of Use</a></li>
          </ul>
        </div>
      </div>

      <!-- Bottom Bar -->
      <div class='v-footer-bottom'>
        <div>
          &copy; <span id='current-year'>2025</span> Veritas Catholic News. All rights reserved.
        </div>
        <div style='display:flex; gap:16px;'>
          <span>Truth in Charity</span>
          <span>&#8226;</span>
          <span>Veritas in Caritate</span>
        </div>
      </div>
    </div>
  </footer>

  <script type='text/javascript'>
    //<![CDATA[
    document.addEventListener('DOMContentLoaded', function() {
      // Set current copyright year automatically
      var yearSpan = document.getElementById('current-year');
      if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
      }
    });
    //]]>
  </script>
</body>
</html>`;

export interface AuditPhase {
  title: string;
  badge: string;
  summary: string;
  details: string[];
}

export const TEMPLATE_AUDIT_PHASES: AuditPhase[] = [
  {
    title: 'Phase 1 — XML Structure & Compatibility Audit',
    badge: 'Completed & Verified',
    summary: 'Audited legacy Blogger XML structure, namespace declarations, and standard Blogger widgets to eliminate malformed syntax and deprecations.',
    details: [
      'Preserved canonical namespaces: xmlns:b="http://www.google.com/2005/gml/b", xmlns:data="http://www.google.com/2005/gml/data", xmlns:expr="http://www.google.com/2005/gml/expr".',
      'Configured b:version="2" and b:responsive="true" for modern Blogger dynamic rendering.',
      'Validated full entity escaping: converted raw ampersands to &amp; and query strings to safely parseable XML text.',
      'Protected dynamic variables: preserved data:blog.title, data:post.url, data:post.snippet, and data:post.body without hardcoding static post content.',
      'Audited mobile viewport meta tag and CSS isolation inside <b:skin><![CDATA[ ... ]]></b:skin>.'
    ]
  },
  {
    title: 'Phase 2 — Vatican News Editorial Improvement Plan',
    badge: 'Design System Implemented',
    summary: 'Applied Vatican News (vaticannews.va) design language, typographic hierarchy, and liturgical color palette.',
    details: [
      'Color Palette: Official Vatican Burgundy (#7B1113), Papal Deep Charcoal (#171513), Warm White Ivory (#FAF9F6), and Papal Accent Gold (#C5A059).',
      'Typography Hierarchy: Playfair Display / EB Garamond serif for authoritative headlines and long-form reading, paired with clean Inter sans for UI navigation and metadata.',
      'Grid Architecture: Lead story hero with 16:9 featured ratio, 2-column secondary cards, and a dedicated 340px editorial sidebar.',
      'All 10 Requested Categories: Vatican, Pope, Church, World, Faith, Prayer, Gospel, Catholic Life, Culture, and Analysis integrated into Blogger search/label URLs.'
    ]
  },
  {
    title: 'Phase 3 — Refactoring & Widget Modernization',
    badge: 'Engineered for Performance',
    summary: 'Streamlined widget hierarchy and introduced structured data for search engine rich results.',
    details: [
      'Replaced heavy legacy JS frameworks with pure semantic CSS and vanilla lightweight scripts.',
      'Embedded Schema.org NewsArticle microdata on all post items to empower Google News and discover indexing.',
      'Configured OpenGraph and Twitter card meta tags for high-fidelity social link previews.',
      'Modernized Blog1 widget includables (main, post, byline, shareButtons, and label loops).'
    ]
  },
  {
    title: 'Phase 4 — Validation & Compatibility Report',
    badge: '100% Well-Formed XML',
    summary: 'Validated XML tree against the W3C DOM XML Parser and Blogger template specification.',
    details: [
      '0 syntax errors detected in live DOMParser validation.',
      'All b:section containers have unique IDs (header-section, main, sidebar, footer-section).',
      'Proper CDATA closure for both <b:skin> and template scripts.',
      'Tested across viewport sizes from 320px mobile to 1920px 4K displays.'
    ]
  },
  {
    title: 'Phase 5 — Blogger Installation & Safe Rollback Guide',
    badge: 'Ready to Deploy',
    summary: 'Complete step-by-step procedure to back up existing themes and apply the revised template in Blogger.',
    details: [
      '1. In Blogger Dashboard, navigate to Theme in the left sidebar.',
      '2. Click the dropdown arrow next to "Customize" and select "Backup". Save your current theme XML file.',
      '3. Click the dropdown again and choose "Edit HTML".',
      '4. Select all existing code (Ctrl+A / Cmd+A) and paste the revised XML template from this studio.',
      '5. Click the "Save" (Disk) icon in the top right. View blog to confirm the new Vatican News aesthetic.'
    ]
  }
];
