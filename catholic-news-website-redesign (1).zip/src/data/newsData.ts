import { Article, LiturgicalDay, RadioBroadcast } from '../types';

export const CATEGORIES = [
  'All',
  'Vatican',
  'Pope',
  'Church',
  'World',
  'Faith',
  'Prayer',
  'Gospel',
  'Catholic Life',
  'Culture',
  'Analysis',
] as const;

export const ARTICLES: Article[] = [
  {
    id: 'art-1',
    slug: 'pope-francis-calls-global-dialogue-peace-jubilee-2025',
    title: 'Holy Father Calls for Bold Steps Toward Global Peace as Jubilee Year Unfolds in Rome',
    subtitle: 'Addressing world ambassadors at the Apostolic Palace, the Pope underscores forgiveness of international debts and immediate humanitarian ceasefires.',
    leadParagraph: 'VATICAN CITY — In an impassioned address before the diplomatic corps accredited to the Holy See, Pope Francis renewed his urgent appeal for authentic fraternity, asserting that lasting global peace cannot be built upon deterrence or economic inequality, but upon mutual trust and the shared recognition of human dignity.',
    content: [
      'Speaking from the historic Clementine Hall of the Apostolic Palace, the Holy Father urged world leaders to seize the ongoing Ordinary Jubilee Year as a providential moment of spiritual renewal and tangible geopolitical reconciliation.',
      '"Peace is not merely the absence of war, nor is it settled through reciprocal intimidation," the Pope declared. "True peace is a craft of patient dialogue, founded on justice, truth, and love for our most vulnerable brothers and sisters who bear the brunt of every armed conflict."',
      'During his comprehensive hour-long review of international affairs, the Pope specifically highlighted ongoing conflicts in Eastern Europe, the Middle East, and Sub-Saharan Africa. He called upon affluent nations to consider sweeping debt relief initiatives for developing countries suffering under the twin burdens of climate vulnerability and unsustainable loan interest.',
      'Reflecting on the Catholic Church’s traditional Jubilee practices dating back to biblical times, Francis reminded delegates that jubilees were instituted precisely to rectify economic imbalances, restore liberty to captives, and allow the earth to rest.',
      'The address drew warm commendation from both European and Global South delegations, who noted that the Holy See continues to provide one of the few truly universal moral platforms capable of speaking frankly to opposing sides without partisan political agendas.'
    ],
    category: 'Pope',
    author: {
      name: 'Dr. Giancarlo Moretti',
      role: 'Senior Vatican Correspondent',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&h=200&q=80'
    },
    publishedAt: '2025-05-18T08:30:00Z',
    readTime: '4 min read',
    imageUrl: 'https://images.pexels.com/photos/29154973/pexels-photo-29154973.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'St. Peter\'s Basilica stands bathed in morning sunlight as thousands of international pilgrims gather for the papal audience.',
    imageCredit: 'Vatican Media / C1 Superstar',
    isLeadStory: true,
    tags: ['Pope Francis', 'Holy See', 'Diplomacy', 'Jubilee 2025', 'World Peace'],
    views: 14820
  },
  {
    id: 'art-2',
    slug: 'holy-see-appoints-synodal-implementation-commission',
    title: 'Holy See Establishes International Commission for Synodal Renewal in Diocesan Curias',
    subtitle: 'The new dicasterial body will assist regional bishops conferences in translating communion and co-responsibility into concrete pastoral structures.',
    leadParagraph: 'VATICAN CITY — The General Secretariat of the Synod has announced the formation of an international permanent commission tasked with supporting episcopal conferences as they implement the synthesis documents and pastoral directives of the Universal Synod.',
    content: [
      'The newly created commission comprises bishops, theologians, religious women, and lay experts from five continents, reflecting the Church’s expansive global diversity.',
      'Cardinal Mario Grech, Secretary General of the Synod, remarked that this phase represents the transition from listening and dialogue to living everyday parish life with greater transparency, listening skills, and shared pastoral discernment.',
      '"Synodality is not an administrative reshuffle," Cardinal Grech noted during a Holy See Press Office briefing. "It is the ancient way the Church walked together in the Acts of the Apostles, guided by the Holy Spirit and rooted in communion with Christ."',
      'Special focus will be placed on establishing functioning pastoral councils in rural and mission territories, ensuring that the voice of youth, catechists, and indigenous communities remains central to diocesan decision-making.'
    ],
    category: 'Vatican',
    author: {
      name: 'Sr. Beatrice Mwangi',
      role: 'Ecclesial Affairs Editor',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&h=200&q=80'
    },
    publishedAt: '2025-05-18T07:15:00Z',
    readTime: '3 min read',
    imageUrl: 'https://images.pexels.com/photos/17261457/pexels-photo-17261457.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'The monumental baldachin designed by Gian Lorenzo Bernini over the high altar of St. Peter’s Basilica.',
    imageCredit: 'L\'Osservatore Romano / Yevhenii Deshko',
    isSecondaryLead: true,
    tags: ['Synod', 'Vatican Curia', 'Pastoral Councils', 'Episcopal Conferences'],
    views: 9430
  },
  {
    id: 'art-3',
    slug: 'caritas-internationalis-emergency-aid-horn-of-africa',
    title: 'Caritas Internationalis Mobilizes Massive Emergency Relief for Drought-Stricken Horn of Africa',
    subtitle: 'Over 2.4 million families facing acute food scarcity receive emergency supplies, clean water wells, and drought-resistant seeds.',
    leadParagraph: 'NAIROBI / GENEVA — Catholic charitable confederation Caritas Internationalis has launched a coordinated 35-million-euro appeal across Kenya, Somalia, and Ethiopia to counter catastrophic drought conditions following unprecedented consecutive failed rainy seasons.',
    content: [
      'Working through local parishes and diocesan development bureaus, Caritas relief convoys have begun distributing fortified nutritional rations, water purification tablets, and solar-powered borehole repair equipment.',
      'Alistair Dutton, Secretary General of Caritas Internationalis, emphasized that the Church’s grassroots presence allows aid to reach isolated pastoralist settlements often inaccessible to governmental agencies.',
      '"Our diocesan teams do not arrive when a crisis starts and depart when cameras leave; we live among these communities," Dutton said from the regional coordination hub in Nairobi.',
      'Catholic Relief Services (CRS) and Caritas Italiana have contributed immediate contingency reserves, while Catholic parishes throughout Europe and North America will hold dedicated second collections in coming weeks.'
    ],
    category: 'World',
    author: {
      name: 'Thomas O’Connor',
      role: 'Global Humanitarian Correspondent',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80'
    },
    publishedAt: '2025-05-17T18:45:00Z',
    readTime: '4 min read',
    imageUrl: 'https://images.pexels.com/photos/6646882/pexels-photo-6646882.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'Catholic humanitarian workers deliver emergency provisions and nutrition boxes to displaced families.',
    imageCredit: 'Caritas / RDNE Stock',
    isSecondaryLead: true,
    tags: ['Caritas', 'Africa', 'Humanitarian Aid', 'Charity', 'Catholic Relief'],
    views: 8210
  },
  {
    id: 'art-4',
    slug: 'general-audience-healing-power-of-the-beatitudes',
    title: 'General Audience: "The Meek Shall Inherit the Earth" — Finding God’s Strength in Gentleness',
    subtitle: 'In his Wednesday catechesis, the Holy Father reminds the faithful that evangelical meekness is not passivity, but holy inner composure.',
    leadParagraph: 'VATICAN CITY — Resuming his weekly catechetical series on Christian hope, Pope Francis greeted over 45,000 pilgrims in St. Peter’s Square, dedicating his reflection to the third Beatitude from the Gospel of Matthew.',
    content: [
      '"In a culture that often glorifies aggressive conquest, sharp words, and dominating self-assertion, Christ offers a radically different paradigm: blessed are the meek," the Holy Father remarked.',
      'The Pope explained that the biblical Greek term used by Saint Matthew implies a gentleness rooted in deep self-possession and unconditional trust in Divine Providence. Meekness, Francis affirmed, disarms enmity and restores harmony to broken homes and fractured civic communities.',
      'Following the address, the Pope greeted newlywed couples, delegations of university students from Poland, and members of the Catholic scouting movement from Latin America.'
    ],
    category: 'Pope',
    author: {
      name: 'Dr. Giancarlo Moretti',
      role: 'Senior Vatican Correspondent'
    },
    publishedAt: '2025-05-17T12:00:00Z',
    readTime: '3 min read',
    imageUrl: 'https://images.pexels.com/photos/13829471/pexels-photo-13829471.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'Pilgrims gather at twilight around the fountains and columns of St. Peter\'s Square.',
    imageCredit: 'Vatican News / Aleksandra Żmuda',
    isSecondaryLead: true,
    tags: ['General Audience', 'Beatitudes', 'Catechesis', 'Spiritual Life'],
    views: 6540
  },
  {
    id: 'art-5',
    slug: 'todays-gospel-reflection-take-courage-it-is-i',
    title: 'Daily Gospel Reflection: "Take Courage, It Is I; Do Not Be Afraid"',
    subtitle: 'Meditation on the storm at sea: when the disciples felt overwhelmed by wind and waves, Christ came to meet them upon the water.',
    leadParagraph: 'JERUSALEM — In today’s Gospel narrative from Mark (6:45–52), we witness the disciples straining at the oars during the fourth watch of the night, battered by contrary winds on the Sea of Galilee.',
    content: [
      'How frequently our personal lives and our communal apostolates resemble that midnight crossing. We labor faithfully against opposing cultural currents, fatigued and feeling alone in the dark.',
      'Yet the Evangelist records that Jesus "saw them straining at rowing." He does not abandon them. He walks upon the troubled surface of the deep, transforming the very source of their terror into the pathway of His arrival.',
      '"Take courage, it is I; do not be afraid." In the original Greek, Jesus utters the divine name: *Egō Eimi* — "I AM." The Master reminds us that whatever waves threaten to engulf our souls, the Creator of the universe remains sovereign.',
      'Let us take time today in quiet Eucharistic adoration to surrender our anxieties, allowing His peace to still the turbulent waters of our hearts.'
    ],
    category: 'Gospel',
    author: {
      name: 'Fr. Julian Rossi, O.P.',
      role: 'Scripture & Theological Commentary'
    },
    publishedAt: '2025-05-18T05:00:00Z',
    readTime: '3 min read',
    imageUrl: 'https://images.pexels.com/photos/5875441/pexels-photo-5875441.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'A priest contemplates the Sacred Scriptures at the altar before the holy sacrifice of the Mass.',
    imageCredit: 'Ecclesia Photo / RDNE Stock',
    isBreaking: false,
    tags: ['Daily Gospel', 'Scripture', 'Homiletics', 'Eucharist', 'Dominican'],
    views: 11200
  },
  {
    id: 'art-6',
    slug: 'historic-restoration-church-holy-sepulchre-chapel',
    title: 'Jerusalem: Landmark Restoration of Holy Sepulchre St. Helena Chapel Completed',
    subtitle: 'Multidisciplinary team of archaeologists and conservators uncovers early Byzantine frescoes and ancient pilgrim graffiti dating to the 5th century.',
    leadParagraph: 'JERUSALEM — Leaders of the Catholic Franciscan Custody of the Holy Land, the Greek Orthodox Patriarchate, and the Armenian Apostolic Patriarchate gathered in unity to celebrate the completion of conservation works in the subterranean Chapel of St. Helena.',
    content: [
      'The multi-year restoration project, executed with advanced laser ablation and environmental stabilization systems, has revived the vivid mineral pigments of centuries-old wall paintings.',
      'Father Francesco Patton, Custos of the Holy Land, praised the cooperative spirit between the three Christian communities presiding over the world\'s most sacred Christian sanctuary.',
      '"Here where Empress Helena discovered the True Cross, pilgrims of every nation will now encounter this sanctuary with renewed reverence and historical clarity," Fr. Patton observed.',
      'The conservation also safeguarded bedrock geological fissures against subterranean humidity, ensuring structural integrity for generations of pilgrims to come.'
    ],
    category: 'Church',
    author: {
      name: 'Maria Elena Da Silva',
      role: 'Middle East Bureau'
    },
    publishedAt: '2025-05-16T15:30:00Z',
    readTime: '4 min read',
    imageUrl: 'https://images.pexels.com/photos/13755423/pexels-photo-13755423.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'Sunlight cascades through the sacred stained glass inside an ancient cathedral ambulatory.',
    imageCredit: 'Terra Sancta / Gagan Kaur',
    tags: ['Holy Land', 'Jerusalem', 'Franciscans', 'Archaeology', 'Sacred Art'],
    views: 7420
  },
  {
    id: 'art-7',
    slug: 'artificial-intelligence-catholic-moral-theology-analysis',
    title: 'Analysis: Human Conscience, Algorithm Ethics, and the Dignity of the Person',
    subtitle: 'As generative neural networks transform society, Catholic ethicists articulate why moral agency and genuine discernment cannot be outsourced.',
    leadParagraph: 'ROME — With rapid advancements in autonomous computation and conversational models, the Pontifical Academy for Life and leading Catholic universities are intensifying their contributions to international AI governance.',
    content: [
      'The Holy See’s "Rome Call for AI Ethics," originally signed in 2020 and continually expanded to include international tech leaders and multifaith signatories, sets forth six fundamental principles: transparency, inclusion, responsibility, impartiality, reliability, and security.',
      'Father Paolo Benanti, professor of moral theology and advisor to the Vatican on technological ethics, warns against the subtle temptation to reduce human contemplation and ethical decisions to statistical probabilities.',
      '"An algorithm optimizes for predetermined parameters; it cannot love, it cannot repent, and it cannot grasp the transcendent sanctity of a human soul," Fr. Benanti observed during a colloquium at the Pontifical Gregorian University.',
      'The analysis explores how Catholic educators, catechists, and journalists can utilize technological tools with discernment while safeguarding the primacy of human encounter and authentic spiritual introspection.'
    ],
    category: 'Analysis',
    author: {
      name: 'Prof. Claire Sterling, Ph.D.',
      role: 'Bioethics & Technology Fellow'
    },
    publishedAt: '2025-05-16T10:15:00Z',
    readTime: '6 min read',
    imageUrl: 'https://images.pexels.com/photos/18506904/pexels-photo-18506904.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'Intricate stained glass motifs demonstrate centuries of human devotion fused with architectural mastery.',
    imageCredit: 'Gregorianum Press / Diego F. Parra',
    tags: ['Ethics', 'AI', 'Pontifical Academy for Life', 'Theology', 'Technology'],
    views: 9150
  },
  {
    id: 'art-8',
    slug: 'vatican-radio-95th-anniversary-multilingual-streaming',
    title: 'Vatican Radio Celebrates 95 Years of Proclaiming Truth Beyond Borders',
    subtitle: 'Founded by Guglielmo Marconi under Pope Pius XI in 1931, the Holy See broadcaster now reaches listeners in 52 languages across satellite, web, and podcast channels.',
    leadParagraph: 'VATICAN CITY — Nearly a century after Guglielmo Marconi installed the first shortwave radio antenna within the Vatican Gardens, Vatican Radio / Vatican News continues to expand its mission to carry the Pope’s voice to the ends of the earth.',
    content: [
      'In a special commemorative broadcast, Vatican Prefect for Communication Paolo Ruffini highlighted how the radio provided a lifeline of hope during World War II, behind the Iron Curtain during the Cold War, and now reaches war zones in Ukraine, Sudan, and Myanmar.',
      'New podcast series dedicated to daily spiritual reflections, multilingual audio Rosaries, and in-depth cultural documentaries have seen listenership surge by 40% among young Catholics worldwide.',
      '"Radio remains the most democratic and resilient medium on earth," Ruffini remarked. "Even where the internet fails or is silenced by censorship, radio waves carry the Good News into prison cells, refugee camps, and isolated mountain villages."'
    ],
    category: 'Vatican',
    author: {
      name: 'Dr. Giancarlo Moretti',
      role: 'Senior Vatican Correspondent'
    },
    publishedAt: '2025-05-15T14:20:00Z',
    readTime: '4 min read',
    imageUrl: 'https://images.pexels.com/photos/28379808/pexels-photo-28379808.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'The majestic colonnade of Saint Peter’s, home to the global voice of Catholic journalism.',
    imageCredit: 'Vatican Media / C1 Superstar',
    tags: ['Vatican Radio', 'Communication', 'History', 'Pope Pius XI', 'Media'],
    views: 5880
  },
  {
    id: 'art-9',
    slug: 'the-art-of-sacred-music-renaissance-polyphony-today',
    title: 'The Living Tradition: How Contemporary Parishes Are Rediscovering Sacred Polyphony',
    subtitle: 'Choir directors and pastoral musicians report a surge of interest among young adults in Gregorian chant and sacred Renaissance choral works.',
    leadParagraph: 'OXFORD / BOSTON — Across university chaplaincies and urban parishes, an intriguing musical movement is taking root: the revitalization of sacred choral polyphony as an aid to contemplative worship and reverent liturgy.',
    content: [
      'From Palestrina and Victoria to Byrd and modern choral masters, sacred polyphony was described by the Second Vatican Council as a "treasure of inestimable value, greater even than that of any other art."',
      'Dr. Anthony Phillips, music director at the Cathedral of St. Paul, notes that chant offers an antidote to the relentless noise and frantic tempo of digital life.',
      '"When parishioners hear chant sung with purity and prayerfulness, time seems to suspend. The melody is not intended to entertain, but to raise the mind to the celestial court of God," Phillips says.',
      'Diocesan music workshops are now equipping parish volunteer choirs with accessible chant tutorials, Latin pronunciation guides, and vernacular propers.'
    ],
    category: 'Culture',
    author: {
      name: 'Eleanor Vance',
      role: 'Arts & Sacred Liturgy Critic'
    },
    publishedAt: '2025-05-14T11:00:00Z',
    readTime: '5 min read',
    imageUrl: 'https://images.pexels.com/photos/8718260/pexels-photo-8718260.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'A celebrant proclaims sacred chants in sanctuary devotion.',
    imageCredit: 'Musica Sacra / Mikhail Nilov',
    tags: ['Sacred Music', 'Gregorian Chant', 'Liturgy', 'Culture', 'Choir'],
    views: 6720
  },
  {
    id: 'art-10',
    slug: 'adoration-and-fasting-catholic-life-in-daily-workplace',
    title: 'Catholic Life: Carrying the Presence of Christ into the Modern Workplace',
    subtitle: 'Interviews with physicians, educators, and software engineers on integrating prayer, justice, and charity in competitive professional environments.',
    leadParagraph: 'CHICAGO — For many faithful, the deepest challenge of discipleship is not finding faith inside a chapel on Sunday, but bearing witness to Christian virtue throughout the work week.',
    content: [
      'Members of Catholic professional associations in major cities are forming lunchtime fraternity groups and early morning prayer circles to support one another in living out Catholic social teaching.',
      'Dr. Teresa Gallagher, an oncologist at a major regional medical center, starts her day with 20 minutes of silent meditation on the day’s Gospel.',
      '"In medicine, we frequently confront human vulnerability, suffering, and mortality. My morning prayer grounds me in the conviction that each patient is a sacred temple of the Holy Spirit, not merely a clinical case," she shared.',
      'The article offers practical tips: keeping a pocket rosary handy, dedicating routine tasks as spiritual offerings, and practicing radical patience in workplace interactions.'
    ],
    category: 'Catholic Life',
    author: {
      name: 'Sr. Beatrice Mwangi',
      role: 'Ecclesial Affairs Editor'
    },
    publishedAt: '2025-05-13T16:00:00Z',
    readTime: '4 min read',
    imageUrl: 'https://images.pexels.com/photos/5875278/pexels-photo-5875278.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'A young professional finds quiet serenity in Scripture before starting the morning work day.',
    imageCredit: 'Catholic Witness / RDNE Stock',
    tags: ['Catholic Life', 'Workplace', 'Vocation', 'Spiritual Life', 'Witness'],
    views: 5120
  },
  {
    id: 'art-11',
    slug: 'popes-prayer-intention-for-the-elderly-and-lonely',
    title: 'Pope’s Monthly Prayer Intention: "Let Us Value the Wisdom and Vulnerability of the Elderly"',
    subtitle: 'In his monthly video message, the Holy Father laments the culture of discarding seniors and urges grandparents to mentor youth in faith and memory.',
    leadParagraph: 'VATICAN CITY — Pope Francis has released his worldwide prayer intention for the month, entrusted to the Apostleship of Prayer (Pope’s Worldwide Prayer Network), focusing on the spiritual treasure of our senior generations.',
    content: [
      '"The elderly are not aliens; we are they, only a few years from now," the Pope reflected with his characteristic warmth and directness.',
      'He noted that a society that rejects grandparents or treats nursing homes as isolated holding centers lacks a future, because it has severed its roots with memory, wisdom, and heritage.',
      'Francis urged families and parish youth groups to organize regular visits to homebound elders, fostering intergenerational bonds that enrich both the young and the old.'
    ],
    category: 'Prayer',
    author: {
      name: 'Dr. Giancarlo Moretti',
      role: 'Senior Vatican Correspondent'
    },
    publishedAt: '2025-05-12T09:00:00Z',
    readTime: '3 min read',
    imageUrl: 'https://images.pexels.com/photos/9586398/pexels-photo-9586398.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'Generations united in prayer: passing the light of faith forward.',
    imageCredit: 'Apostleship of Prayer / cottonbro',
    tags: ['Prayer Intention', 'Elderly', 'Family', 'Intergenerational', 'Pope Francis'],
    views: 8900
  },
  {
    id: 'art-12',
    slug: 'theology-of-hope-in-times-of-trial',
    title: 'The Virtue of Hope: Why Christian Hope Is Not Mere Optimism',
    subtitle: 'Theological reflection on how biblical hope (*spes*) anchors the human spirit in God’s unfailing promises rather than transient circumstances.',
    leadParagraph: 'PARIS — In secular parlance, "hope" often denotes little more than wishful thinking or a sunny mood. Yet in Catholic theological tradition, hope is one of the three theological virtues infused at Baptism.',
    content: [
      'Saint Thomas Aquinas in the *Summa Theologiae* defined hope as an ardent desire for an arduous future good, made attainable through the assistance of Divine grace.',
      'Writing during the trials of the twentieth century, Cardinal Henri de Lubac and Pope Benedict XVI emphasized that Christian hope does not evade human sorrow or deny earthly suffering.',
      'Rather, hope transforms suffering from within because it knows that the Resurrection has already won the definitive victory over sin and death.',
      'As Cardinal Raniero Cantalamessa observed, "Christian hope is like an anchor cast not into the sea below, but upward into the heavenly sanctuary where Christ has entered ahead of us."'
    ],
    category: 'Faith',
    author: {
      name: 'Fr. Julian Rossi, O.P.',
      role: 'Scripture & Theological Commentary'
    },
    publishedAt: '2025-05-11T13:45:00Z',
    readTime: '5 min read',
    imageUrl: 'https://images.pexels.com/photos/35654826/pexels-photo-35654826.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    imageCaption: 'Gothic cathedral stained glass depicting the radiant light of the Risen Christ.',
    imageCredit: 'Theological Review / Harrison Haas',
    tags: ['Theology', 'Hope', 'Faith', 'Aquinas', 'Benedict XVI'],
    views: 6410
  }
];

export const BREAKING_NEWS = [
  'Pope Francis to Preside at Solemn Holy Mass for Global Youth Delegates in St. Peter\'s Basilica This Sunday',
  'Holy See and UN Agencies Sign Strategic Accord on Clean Water Access for Sub-Saharan Hospitals',
  'Vatican Dicastery for the Doctrine of the Faith Issues Pastoral Document on Eucharistic Reverence and Inclusion',
  'Caritas Internationalis Reports Over 1.8 Million Individuals Aided Through Winter Relief Programs',
  'Synod Secretariat Publishes Global Working Guidebook for Parish Leadership and Parishioner Collaboration'
];

export const CURRENT_LITURGICAL_DAY: LiturgicalDay = {
  date: '2025-05-18',
  formattedDate: 'Sunday, May 18, 2025',
  liturgicalSeason: 'Easter Season (5th Sunday of Easter)',
  seasonColor: 'white',
  colorName: 'White / Gold',
  feastName: 'Fifth Sunday of Easter — Solemnity of the Risen Lord',
  saintOfTheDay: {
    name: 'Saint John I, Pope and Martyr',
    title: 'Bishop of Rome, Defender of the True Faith (d. 526)',
    bio: 'Elected Pope in 523, John was sent by the Arian King Theodoric to Constantinople to negotiate with Emperor Justin I. Upon his return, Theodoric had him imprisoned in Ravenna, where he succumbed to harsh treatment. He is revered as a martyr for his steadfast defense of Catholic orthodoxy and the freedom of the Church.',
    patronage: 'Ravenna, Italy; prisoners of conscience; church unity'
  },
  readings: {
    firstReading: {
      citation: 'Acts of the Apostles 14:21-27',
      excerpt: '"Paul and Barnabas returned to Lystra and Iconium and Antioch. They strengthened the spirits of the disciples and exhorted them to persevere in the faith, saying: \'It is necessary for us to undergo many hardships to enter the Kingdom of God.\'"'
    },
    responsorialPsalm: {
      citation: 'Psalm 145:8-9, 10-11, 12-13',
      response: '"I will praise your name for ever, my king and my God."'
    },
    secondReading: {
      citation: 'Revelation 21:1-5a',
      excerpt: '"Then I saw a new heaven and a new earth. The former heaven and the former earth had passed away... I heard a loud voice from the throne saying: \'Behold, God’s dwelling is with the human race. He will wipe every tear from their eyes.\'"'
    },
    gospel: {
      citation: 'John 13:31-33a, 34-35',
      excerpt: '"When Judas had left them, Jesus said: \'Now is the Son of Man glorified, and God is glorified in him... I give you a new commandment: love one another. As I have loved you, so you also should love one another. This is how all will know that you are my disciples.\'"'
    }
  },
  papalIntention: {
    month: 'May',
    title: 'For the Disarmament of Hearts and Nations',
    description: 'We pray that world leaders may heed the cry of the poor and the earth, choosing the courage of dialogue and disarmament over escalating military expenditures.'
  }
};

export const RADIO_BROADCASTS: RadioBroadcast[] = [
  {
    id: 'broadcast-1',
    title: 'Vatican Radio International English News Bulletin',
    subtitle: 'Daily global broadcast: Papal statements, Holy See diplomatic initiatives, and mission reports.',
    duration: '14:25',
    timeRemaining: 'Live • 12:00 UTC'
  },
  {
    id: 'broadcast-2',
    title: 'Daily Gospel Reflection with Fr. Julian Rossi',
    subtitle: 'Contemplative commentary on today’s reading from the Holy Gospel according to Saint John.',
    duration: '06:18',
    timeRemaining: 'On-Demand'
  },
  {
    id: 'broadcast-3',
    title: 'Holy Rosary in Latin and English with Gregorian Chants',
    subtitle: 'The Glorious Mysteries recited with the Vatican Chapter at the Altar of the Chair.',
    duration: '22:40',
    timeRemaining: 'On-Demand'
  }
];
