import React, { useState } from 'react';
import { 
  Search, 
  Menu, 
  X, 
  Radio, 
  BookOpen, 
  Code2, 
  Calendar
} from 'lucide-react';
import { Category, LiturgicalDay } from '../types';
import { CATEGORIES } from '../data/newsData';

interface HeaderProps {
  activeCategory: Category;
  onSelectCategory: (category: Category) => void;
  onOpenSearch: () => void;
  onOpenAudio: () => void;
  onOpenLiturgyModal: () => void;
  liturgicalDay: LiturgicalDay;
  isXmlStudioOpen: boolean;
  onToggleXmlStudio: () => void;
  onOpenPolicyModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeCategory,
  onSelectCategory,
  onOpenSearch,
  onOpenAudio,
  onOpenLiturgyModal,
  liturgicalDay,
  isXmlStudioOpen,
  onToggleXmlStudio,
  onOpenPolicyModal
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="w-full bg-[#FAF9F6] text-[#1C1917] border-b border-[#E5E0D8] sticky top-0 z-40 transition-shadow shadow-xs">
      {/* 1. Top Utility Bar */}
      <div className="bg-[#580C0E] text-[#F5F5F4] text-xs py-1.5 px-4 border-b border-[#7B1113]/40">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          {/* Left: Liturgical Season & Date */}
          <div className="flex items-center gap-3 text-stone-200">
            <span className="font-medium tracking-wide flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#C5A059]" />
              {liturgicalDay.formattedDate}
            </span>
            <span className="hidden sm:inline text-stone-400">|</span>
            <button 
              onClick={onOpenLiturgyModal}
              className="inline-flex items-center gap-1.5 bg-[#C5A059]/20 hover:bg-[#C5A059]/30 text-[#E8D39E] px-2 py-0.5 rounded text-[11px] font-semibold tracking-wide border border-[#C5A059]/40 transition"
              title="Click to view full daily Lectionary readings &amp; Saint of the Day"
            >
              <span className="w-2 h-2 rounded-full bg-white inline-block"></span>
              {liturgicalDay.liturgicalSeason}
            </button>
          </div>

          {/* Right: Quick actions & Studio Switcher */}
          <div className="flex items-center gap-3 text-stone-300">
            <button 
              onClick={onOpenAudio}
              className="inline-flex items-center gap-1.5 hover:text-white transition text-xs font-medium cursor-pointer"
            >
              <Radio className="w-3.5 h-3.5 text-red-300 animate-pulse" />
              <span>Vatican Radio Broadcast</span>
            </button>
            <span className="text-stone-500">|</span>
            <button 
              onClick={onOpenLiturgyModal}
              className="hidden sm:inline-flex items-center gap-1 hover:text-[#E8D39E] transition"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>Daily Readings</span>
            </button>
            <span className="hidden sm:inline text-stone-500">|</span>
            
            {/* Blogger XML Studio Callout Pill */}
            <button
              onClick={onToggleXmlStudio}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold transition shadow-xs ${
                isXmlStudioOpen 
                  ? 'bg-[#C5A059] text-stone-950 ring-2 ring-[#E8D39E]' 
                  : 'bg-stone-800/90 text-stone-100 hover:bg-stone-700 border border-stone-600'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>{isXmlStudioOpen ? 'Exit Template Studio' : 'Blogger XML Studio'}</span>
              <span className="bg-[#7B1113] text-white text-[10px] px-1 py-0.2 rounded font-mono font-bold">XML</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Main Masthead */}
      <div className="bg-white border-b border-[#E5E0D8] py-4 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Left: Mobile hamburger & Edition */}
          <div className="flex items-center gap-3 lg:w-1/4">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-stone-700 hover:text-[#7B1113] hover:bg-stone-100 rounded"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            
            <div className="hidden lg:flex flex-col text-xs text-stone-600 border-l-2 border-[#7B1113] pl-3">
              <span className="font-semibold text-stone-800 tracking-wide">INTERNATIONAL ENGLISH EDITION</span>
              <span className="text-stone-500 text-[11px]">Vatican City • Global Newsroom</span>
            </div>
          </div>

          {/* Center: Publication Title / Logo */}
          <div className="text-center flex-1">
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-full bg-[#7B1113] text-white flex items-center justify-center shadow-sm">
                {/* Papal Cross Emblem */}
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M11 2h2v6h5v2h-5v4h3v2h-3v6h-2v-6H8v-2h3v-4H6V8h5V2z"/>
                </svg>
              </div>
              <span className="text-[11px] font-bold tracking-widest text-[#7B1113] uppercase font-mono">
                Ad Maiorem Dei Gloriam
              </span>
            </div>
            
            <h1 className="font-masthead text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-wider text-[#580C0E] uppercase hover:opacity-90 transition cursor-pointer"
                onClick={() => { onSelectCategory('All'); }}>
              VERITAS CATHOLIC NEWS
            </h1>
            
            <p className="font-serif-headline italic text-xs sm:text-sm text-stone-600 tracking-wide mt-0.5">
              Truth in Charity • Comprehensive Vatican Coverage &amp; International Catholic Chronicles
            </p>
          </div>

          {/* Right: Search & Actions */}
          <div className="flex items-center justify-end gap-2 lg:w-1/4">
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-2 text-xs font-medium text-stone-700 hover:text-[#7B1113] bg-stone-100 hover:bg-stone-200/80 px-3 py-2 rounded-full border border-stone-200 transition"
              title="Search Catholic News Articles"
            >
              <Search className="w-4 h-4 text-stone-600" />
              <span className="hidden sm:inline">Search News</span>
            </button>
            
            <button
              onClick={onOpenPolicyModal}
              className="hidden md:inline-flex text-xs text-stone-500 hover:text-stone-900 px-2 py-1 transition"
              title="Editorial Ethics & Standards"
            >
              Editorial Ethics
            </button>
          </div>
        </div>
      </div>

      {/* 3. Primary Navigation Bar */}
      <nav className="bg-[#7B1113] text-white shadow-md hidden lg:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-4">
          <ul className="flex items-center space-x-1 overflow-x-auto py-0 text-sm font-medium tracking-wide">
            {CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat;
              return (
                <li key={cat}>
                  <button
                    onClick={() => {
                      onSelectCategory(cat);
                    }}
                    className={`px-3.5 py-3 transition uppercase text-xs tracking-wider whitespace-nowrap font-semibold border-b-2 ${
                      isActive 
                        ? 'bg-[#580C0E] text-[#E8D39E] border-[#C5A059]' 
                        : 'text-stone-100 hover:bg-[#580C0E]/70 hover:text-white border-transparent'
                    }`}
                  >
                    {cat}
                  </button>
                </li>
              );
            })}
          </ul>

          <div className="flex items-center gap-2 text-xs pl-4 border-l border-[#580C0E]">
            <button 
              onClick={onOpenAudio}
              className="flex items-center gap-1.5 text-stone-200 hover:text-white bg-[#580C0E] px-2.5 py-1.5 rounded transition font-medium"
            >
              <Radio className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>Live Radio</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#1C1917] text-white border-b border-stone-800 px-4 py-4 space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-stone-800">
            <span className="text-xs uppercase tracking-wider text-stone-400 font-bold">News Desks</span>
            <span className="text-xs text-[#C5A059]">{liturgicalDay.liturgicalSeason}</span>
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  onSelectCategory(cat);
                  setMobileMenuOpen(false);
                }}
                className={`text-left px-3 py-2 text-xs uppercase tracking-wider font-semibold rounded ${
                  activeCategory === cat
                    ? 'bg-[#7B1113] text-white'
                    : 'text-stone-300 hover:bg-stone-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-800 space-y-2 text-xs">
            <button
              onClick={() => {
                onToggleXmlStudio();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between px-3 py-2 bg-[#C5A059] text-stone-950 font-bold rounded"
            >
              <span>Blogger XML Template Studio</span>
              <Code2 className="w-4 h-4" />
            </button>
            
            <button
              onClick={() => {
                onOpenAudio();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between px-3 py-2 bg-stone-800 text-stone-200 rounded"
            >
              <span>Vatican Radio Broadcast</span>
              <Radio className="w-4 h-4 text-red-400" />
            </button>

            <button
              onClick={() => {
                onOpenLiturgyModal();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between px-3 py-2 bg-stone-800 text-stone-200 rounded"
            >
              <span>Daily Scripture &amp; Saint of Day</span>
              <BookOpen className="w-4 h-4 text-[#C5A059]" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
