import React, { useState, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, X, Radio, SkipForward, SkipBack } from 'lucide-react';
import { RADIO_BROADCASTS } from '../data/newsData';
import { RadioBroadcast } from '../types';

interface AudioBroadcastPlayerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AudioBroadcastPlayer: React.FC<AudioBroadcastPlayerProps> = ({ isOpen, onClose }) => {
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(24);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(80);

  const currentTrack: RadioBroadcast = RADIO_BROADCASTS[currentTrackIndex];

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => (prev >= 100 ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  if (!isOpen) return null;

  return (
    <div className="bg-[#1C1917] text-white border-b-2 border-[#C5A059] py-3 px-4 shadow-xl relative z-30 transition-all animate-in slide-in-from-top duration-200">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Track Info */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="w-10 h-10 rounded-lg bg-[#7B1113] flex items-center justify-center flex-shrink-0 text-white shadow-sm">
            <Radio className={`w-5 h-5 ${isPlaying ? 'text-[#E8D39E] animate-pulse' : 'text-white'}`} />
          </div>
          <div className="overflow-hidden">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold tracking-wider bg-[#C5A059] text-stone-950 px-1.5 py-0.5 rounded">
                Vatican Radio
              </span>
              <span className="text-xs text-stone-400">{currentTrack.timeRemaining}</span>
            </div>
            <h4 className="font-semibold text-sm text-stone-100 truncate">{currentTrack.title}</h4>
            <p className="text-xs text-stone-400 truncate">{currentTrack.subtitle}</p>
          </div>
        </div>

        {/* Player Controls & Scrubber */}
        <div className="flex flex-col items-center gap-1.5 w-full md:w-2/5">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setCurrentTrackIndex((prev) => (prev === 0 ? RADIO_BROADCASTS.length - 1 : prev - 1))}
              className="text-stone-400 hover:text-white transition"
              title="Previous broadcast"
            >
              <SkipBack className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-9 h-9 rounded-full bg-[#C5A059] hover:bg-[#E8D39E] text-stone-950 flex items-center justify-center transition shadow-md"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>
            <button
              onClick={() => setCurrentTrackIndex((prev) => (prev + 1) % RADIO_BROADCASTS.length)}
              className="text-stone-400 hover:text-white transition"
              title="Next broadcast"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          <div className="w-full flex items-center gap-2 text-[11px] text-stone-400">
            <span>03:15</span>
            <div 
              className="flex-1 bg-stone-700 h-1.5 rounded-full overflow-hidden cursor-pointer"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const pos = (e.clientX - rect.left) / rect.width;
                setProgress(Math.floor(pos * 100));
              }}
            >
              <div 
                className="bg-[#C5A059] h-full transition-all"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <span>{currentTrack.duration}</span>
          </div>
        </div>

        {/* Volume & Close */}
        <div className="flex items-center gap-4 w-full md:w-auto justify-end">
          <div className="hidden sm:flex items-center gap-2">
            <button 
              onClick={() => setIsMuted(!isMuted)} 
              className="text-stone-400 hover:text-white"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <input
              type="range"
              min="0"
              max="100"
              value={isMuted ? 0 : volume}
              onChange={(e) => {
                setVolume(Number(e.target.value));
                if (isMuted) setIsMuted(false);
              }}
              className="w-16 h-1 bg-stone-700 rounded-lg accent-[#C5A059] cursor-pointer"
            />
          </div>

          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-1 rounded-md hover:bg-stone-800 transition"
            title="Close audio player"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

      </div>
    </div>
  );
};
