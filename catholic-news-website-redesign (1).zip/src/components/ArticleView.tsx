import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Clock, 
  Calendar, 
  Share2, 
  Check, 
  Printer, 
  ChevronLeft, 
  ChevronRight, 
  MessageSquare,
  Send
} from 'lucide-react';
import { Article } from '../types';

interface ArticleViewProps {
  article: Article;
  relatedArticles: Article[];
  prevArticle?: Article;
  nextArticle?: Article;
  onBack: () => void;
  onSelectArticle: (article: Article) => void;
  onSelectCategory: (category: any) => void;
}

export const ArticleView: React.FC<ArticleViewProps> = ({
  article,
  relatedArticles,
  prevArticle,
  nextArticle,
  onBack,
  onSelectArticle,
  onSelectCategory
}) => {
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [readTheme, setReadTheme] = useState<'ivory' | 'white' | 'sepia'>('ivory');
  const [copied, setCopied] = useState(false);
  const [comments, setComments] = useState<Array<{ name: string; date: string; text: string }>>([
    {
      name: 'Rev. Mark Connelly',
      date: 'May 18, 2025 at 10:14 AM',
      text: 'A profoundly inspiring perspective. The Holy Father’s insistence on debt forgiveness touches upon the very heart of the biblical jubilee proclaimed in Leviticus 25.'
    },
    {
      name: 'Maria Santos',
      date: 'May 18, 2025 at 11:32 AM',
      text: 'Thank you Veritas for providing thoughtful, balanced journalism that upholds the dignity of truth and communion.'
    }
  ]);
  const [newCommentName, setNewCommentName] = useState('');
  const [newCommentText, setNewCommentText] = useState('');
  const [commentSuccess, setCommentSuccess] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentName.trim() || !newCommentText.trim()) return;
    setComments([
      ...comments,
      {
        name: newCommentName.trim(),
        date: 'Just now',
        text: newCommentText.trim()
      }
    ]);
    setNewCommentName('');
    setNewCommentText('');
    setCommentSuccess(true);
    setTimeout(() => setCommentSuccess(false), 4000);
  };

  const themeClasses = {
    ivory: 'bg-[#FAF9F6] text-[#1C1917]',
    white: 'bg-white text-stone-900',
    sepia: 'bg-[#F4EFEA] text-[#2D241E]'
  }[readTheme];

  const fontSizeClass = {
    normal: 'text-lg leading-relaxed',
    large: 'text-xl leading-loose',
    xlarge: 'text-2xl leading-loose'
  }[fontSize];

  return (
    <article className={`max-w-4xl mx-auto border border-[#E5E0D8] p-6 sm:p-10 mb-16 shadow-xs ${themeClasses}`}>
      
      {/* 1. Top Bar: Back button, breadcrumbs & reading controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-stone-200 mb-8">
        {/* Breadcrumb Navigation */}
        <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-stone-500 font-medium">
          <button
            onClick={onBack}
            className="flex items-center gap-1 text-[#7B1113] hover:underline font-bold"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>
          <span>/</span>
          <button
            onClick={() => onSelectCategory(article.category)}
            className="text-stone-700 hover:text-[#7B1113] font-semibold"
          >
            {article.category}
          </button>
          <span>/</span>
          <span className="truncate max-w-[200px] text-stone-400">Dispatch</span>
        </div>

        {/* Typography & Mode Controls */}
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1 bg-stone-100 p-1 rounded border border-stone-200">
            <span className="text-[11px] font-bold text-stone-500 px-1">Text:</span>
            <button
              onClick={() => setFontSize('normal')}
              className={`px-2 py-0.5 rounded text-xs font-semibold ${fontSize === 'normal' ? 'bg-[#7B1113] text-white' : 'text-stone-700 hover:bg-stone-200'}`}
              title="Standard Font Size"
            >
              A
            </button>
            <button
              onClick={() => setFontSize('large')}
              className={`px-2 py-0.5 rounded text-xs font-bold ${fontSize === 'large' ? 'bg-[#7B1113] text-white' : 'text-stone-700 hover:bg-stone-200'}`}
              title="Large Font Size"
            >
              A+
            </button>
          </div>

          <div className="flex items-center gap-1 bg-stone-100 p-1 rounded border border-stone-200">
            <button
              onClick={() => setReadTheme('ivory')}
              className={`w-5 h-5 rounded-full border border-stone-300 bg-[#FAF9F6] ${readTheme === 'ivory' ? 'ring-2 ring-[#7B1113]' : ''}`}
              title="Warm Ivory Theme"
            />
            <button
              onClick={() => setReadTheme('white')}
              className={`w-5 h-5 rounded-full border border-stone-300 bg-white ${readTheme === 'white' ? 'ring-2 ring-[#7B1113]' : ''}`}
              title="Crisp White Theme"
            />
            <button
              onClick={() => setReadTheme('sepia')}
              className={`w-5 h-5 rounded-full border border-stone-300 bg-[#F4EFEA] ${readTheme === 'sepia' ? 'ring-2 ring-[#7B1113]' : ''}`}
              title="Sepia Reading Theme"
            />
          </div>
        </div>
      </div>

      {/* 2. Article Header */}
      <header className="mb-8">
        <div className="inline-block bg-[#7B1113] text-white text-xs font-bold uppercase tracking-wider px-2.5 py-1 mb-3 rounded-xs">
          {article.category} Chronicle
        </div>

        <h1 className="font-serif-headline text-3xl sm:text-4xl md:text-5xl font-black text-[#1C1917] leading-tight mb-4">
          {article.title}
        </h1>

        <p className="font-serif-body text-xl sm:text-2xl text-stone-600 italic leading-snug border-l-3 border-[#C5A059] pl-4 mb-6">
          {article.subtitle}
        </p>

        {/* Byline & Metadata */}
        <div className="flex flex-wrap items-center justify-between gap-4 py-4 border-y border-stone-200 text-xs text-stone-600">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#7B1113] text-white flex items-center justify-center font-serif-headline font-bold text-sm">
              {article.author.name.charAt(0)}
            </div>
            <div>
              <div className="font-semibold text-stone-900 text-sm">{article.author.name}</div>
              <div className="text-stone-500">{article.author.role}</div>
            </div>
          </div>

          <div className="flex items-center gap-4 text-stone-500">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-[#C5A059]" />
              {new Date(article.publishedAt).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 font-medium text-[#7B1113]">
              <Clock className="w-3.5 h-3.5" />
              {article.readTime}
            </span>
          </div>
        </div>
      </header>

      {/* 3. Featured Image with Caption & Credit */}
      <figure className="mb-10">
        <div className="aspect-16/10 overflow-hidden bg-stone-100 rounded-xs border border-stone-200">
          <img
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-full object-cover"
          />
        </div>
        <figcaption className="mt-2 text-xs text-stone-500 flex justify-between items-start gap-4">
          <span className="italic">{article.imageCaption}</span>
          <span className="font-semibold uppercase tracking-wider text-stone-600 whitespace-nowrap">
            Photo: {article.imageCredit}
          </span>
        </figcaption>
      </figure>

      {/* 4. Article Body Content */}
      <div className={`font-serif-body ${fontSizeClass} text-stone-800 space-y-6 mb-12`}>
        {/* Lead Paragraph with drop-cap */}
        <p className="editorial-dropcap font-semibold text-stone-900 text-xl leading-relaxed">
          {article.leadParagraph}
        </p>

        {article.content.map((paragraph, idx) => (
          <React.Fragment key={idx}>
            <p className="leading-relaxed">{paragraph}</p>
            {/* Pull Quote after 2nd paragraph */}
            {idx === 1 && (
              <blockquote className="my-8 py-4 px-6 bg-[#FAF7F2] border-l-4 border-[#7B1113] rounded-r text-stone-800 font-serif-headline text-xl italic font-semibold shadow-2xs">
                &quot;Peace is a craft of patient dialogue, founded on justice, truth, and love for our most vulnerable brothers and sisters.&quot;
              </blockquote>
            )}
          </React.Fragment>
        ))}
      </div>

      {/* 5. Tag Labels */}
      <div className="mb-8 pt-4 border-t border-stone-200">
        <span className="text-xs font-bold uppercase tracking-wider text-stone-500 block mb-2">
          Archival Labels:
        </span>
        <div className="flex flex-wrap gap-2">
          {article.tags.map((tag) => (
            <span
              key={tag}
              className="text-xs bg-stone-100 hover:bg-stone-200 text-stone-700 px-2.5 py-1 rounded-sm border border-stone-200 transition cursor-pointer"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>

      {/* 6. Social Share Bar */}
      <div className="bg-[#FAF7F2] border border-[#E5E0D8] p-4 rounded-sm flex flex-col sm:flex-row items-center justify-between gap-4 mb-12">
        <span className="font-serif-headline text-sm font-bold uppercase tracking-wider text-[#7B1113]">
          Share This Dispatch
        </span>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-stone-50 text-stone-800 text-xs font-semibold rounded border border-stone-300 transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5 text-stone-500" />}
            <span>{copied ? 'Link Copied!' : 'Copy Link'}</span>
          </button>
          
          <a
            href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title)}&url=${encodeURIComponent(window.location.href)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 px-3 py-1.5 bg-[#1C1917] hover:bg-black text-white text-xs font-semibold rounded transition"
          >
            <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
            </svg>
            <span>X / Twitter</span>
          </a>

          <a
            href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 px-3 py-1.5 bg-[#1877F2] hover:bg-[#0d65d9] text-white text-xs font-semibold rounded transition"
          >
            <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            <span>Facebook</span>
          </a>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1 px-3 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold rounded transition"
            title="Print Article"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* 7. Previous / Next Article Navigation */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-6 border-y border-stone-200 mb-12">
        {prevArticle ? (
          <div 
            onClick={() => onSelectArticle(prevArticle)}
            className="p-3 bg-stone-50 hover:bg-stone-100 rounded border border-stone-200 cursor-pointer group transition"
          >
            <div className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-stone-400 group-hover:text-[#7B1113]">
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous Dispatch</span>
            </div>
            <h5 className="font-serif-headline text-sm font-bold text-stone-800 group-hover:text-[#7B1113] truncate mt-1">
              {prevArticle.title}
            </h5>
          </div>
        ) : <div />}

        {nextArticle && (
          <div 
            onClick={() => onSelectArticle(nextArticle)}
            className="p-3 bg-stone-50 hover:bg-stone-100 rounded border border-stone-200 cursor-pointer group transition sm:text-right"
          >
            <div className="flex items-center justify-end gap-1 text-[11px] font-bold uppercase tracking-wider text-stone-400 group-hover:text-[#7B1113]">
              <span>Next Dispatch</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
            <h5 className="font-serif-headline text-sm font-bold text-stone-800 group-hover:text-[#7B1113] truncate mt-1">
              {nextArticle.title}
            </h5>
          </div>
        )}
      </div>

      {/* 8. Related Articles Section */}
      <section className="mb-12">
        <h3 className="font-serif-headline text-xl font-bold uppercase tracking-wider text-[#7B1113] border-b-2 border-[#7B1113] pb-2 mb-6">
          Related Ecclesial Dispatches
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {relatedArticles.slice(0, 3).map((rel) => (
            <div
              key={rel.id}
              onClick={() => onSelectArticle(rel)}
              className="group cursor-pointer bg-white border border-stone-200 hover:border-stone-400 p-3 transition"
            >
              <div className="aspect-16/10 bg-stone-100 overflow-hidden mb-2">
                <img
                  src={rel.imageUrl}
                  alt={rel.title}
                  className="w-full h-full object-cover group-hover:scale-104 transition duration-300"
                />
              </div>
              <span className="text-[10px] font-bold uppercase text-[#7B1113]">
                {rel.category}
              </span>
              <h5 className="font-serif-headline text-xs font-bold text-stone-900 group-hover:text-[#7B1113] line-clamp-2 mt-1">
                {rel.title}
              </h5>
            </div>
          ))}
        </div>
      </section>

      {/* 9. Reader Reflections & Comments */}
      <section className="bg-stone-50 border border-stone-200 p-6 rounded-sm">
        <div className="flex items-center justify-between pb-3 border-b border-stone-200 mb-6">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#7B1113]" />
            <h3 className="font-serif-headline text-lg font-bold text-stone-900">
              Reader Reflections ({comments.length})
            </h3>
          </div>
          <span className="text-xs text-stone-500 font-serif-body italic">
            Reflections undergo editorial review for charity &amp; truth.
          </span>
        </div>

        {/* Existing Comments */}
        <div className="space-y-4 mb-8">
          {comments.map((comm, idx) => (
            <div key={idx} className="bg-white p-4 border border-stone-200 rounded-sm">
              <div className="flex justify-between items-center text-xs text-stone-500 mb-1.5">
                <span className="font-bold text-stone-800">{comm.name}</span>
                <span>{comm.date}</span>
              </div>
              <p className="text-sm font-serif-body text-stone-700 leading-relaxed">
                {comm.text}
              </p>
            </div>
          ))}
        </div>

        {/* Post Comment Form */}
        <form onSubmit={handleAddComment} className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700">
            Submit a Pastoral Reflection
          </h4>

          {commentSuccess && (
            <div className="bg-emerald-50 text-emerald-800 border border-emerald-300 p-3 rounded text-xs font-medium">
              Thank you! Your reflection has been posted to this dispatch.
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Your Name / Title"
              value={newCommentName}
              onChange={(e) => setNewCommentName(e.target.value)}
              required
              className="bg-white border border-stone-300 px-3 py-2 text-xs rounded focus:outline-none focus:border-[#7B1113]"
            />
          </div>
          <textarea
            rows={3}
            placeholder="Share your reflection on this chronicle..."
            value={newCommentText}
            onChange={(e) => setNewCommentText(e.target.value)}
            required
            className="w-full bg-white border border-stone-300 p-3 text-xs rounded focus:outline-none focus:border-[#7B1113]"
          />
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#7B1113] hover:bg-[#580C0E] text-white text-xs font-bold uppercase tracking-wider rounded transition"
          >
            <span>Publish Reflection</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </section>

    </article>
  );
};
