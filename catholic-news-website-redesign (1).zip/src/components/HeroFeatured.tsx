import React from 'react';
import { Clock, ArrowRight } from 'lucide-react';
import { Article } from '../types';

interface HeroFeaturedProps {
  leadStory: Article;
  secondaryStories: Article[];
  onSelectArticle: (article: Article) => void;
}

export const HeroFeatured: React.FC<HeroFeaturedProps> = ({
  leadStory,
  secondaryStories,
  onSelectArticle,
}) => {
  return (
    <section className="mb-12">
      {/* Editorial Section Label */}
      <div className="flex items-center justify-between border-b-2 border-[#7B1113] pb-2 mb-6">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 bg-[#7B1113]"></span>
          <h2 className="font-serif-headline text-lg sm:text-xl font-bold uppercase tracking-wider text-[#7B1113]">
            Lead Editorial Chronicle &amp; Holy See Highlights
          </h2>
        </div>
        <span className="text-xs uppercase font-medium text-stone-500 tracking-wider hidden sm:inline">
          Special Diplomatic Report
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* 1. Main Lead Hero Story (7 cols) */}
        <div className="lg:col-span-7 flex flex-col bg-white border border-[#E5E0D8] border-t-4 border-t-[#7B1113] shadow-xs group hover:shadow-md transition">
          {/* Hero Image */}
          <div 
            className="relative aspect-16/9 overflow-hidden bg-stone-100 cursor-pointer"
            onClick={() => onSelectArticle(leadStory)}
          >
            <img
              src={leadStory.imageUrl}
              alt={leadStory.title}
              className="w-full h-full object-cover group-hover:scale-102 transition duration-500 ease-out"
              loading="eager"
            />
            <div className="absolute top-3 left-3 bg-[#7B1113] text-white px-2.5 py-1 text-xs font-bold uppercase tracking-wider rounded-xs shadow-xs">
              {leadStory.category}
            </div>
            <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-xs text-stone-200 text-[11px] px-2 py-0.5 rounded">
              {leadStory.imageCredit}
            </div>
          </div>

          {/* Lead Content */}
          <div className="p-6 flex flex-col flex-1">
            <div className="flex items-center gap-3 text-xs text-stone-500 mb-2">
              <span className="flex items-center gap-1 font-medium text-[#7B1113]">
                <Clock className="w-3.5 h-3.5" />
                {leadStory.readTime}
              </span>
              <span>•</span>
              <span>{new Date(leadStory.publishedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
            </div>

            <h3 
              onClick={() => onSelectArticle(leadStory)}
              className="font-serif-headline text-2xl sm:text-3xl font-extrabold text-[#1C1917] hover:text-[#7B1113] leading-tight mb-3 cursor-pointer transition"
            >
              {leadStory.title}
            </h3>

            <p className="font-serif-body text-base sm:text-lg text-stone-700 leading-relaxed mb-4 flex-1">
              {leadStory.subtitle}
            </p>

            <div className="pt-4 border-t border-stone-200 flex items-center justify-between text-xs text-stone-600">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-stone-900">{leadStory.author.name}</span>
                <span>—</span>
                <span className="text-stone-500 italic">{leadStory.author.role}</span>
              </div>
              <button 
                onClick={() => onSelectArticle(leadStory)}
                className="inline-flex items-center gap-1 font-semibold text-[#7B1113] hover:text-[#580C0E] transition"
              >
                <span>Read Dispatch</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* 2. Secondary Editorial Highlights (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-stone-100/70 p-3 border-b border-stone-300 flex items-center justify-between">
            <span className="text-xs uppercase font-bold tracking-wider text-stone-800 font-serif-headline">
              Vatican &amp; Global Despatches
            </span>
            <span className="text-[11px] font-mono text-[#7B1113] font-bold">KEY BRIEFINGS</span>
          </div>

          <div className="flex flex-col gap-4">
            {secondaryStories.map((story) => (
              <article 
                key={story.id}
                className="bg-white border border-[#E5E0D8] p-4 flex gap-4 hover:border-stone-400 transition shadow-2xs group cursor-pointer"
                onClick={() => onSelectArticle(story)}
              >
                {/* Thumbnail */}
                <div className="w-28 sm:w-36 aspect-16/11 flex-shrink-0 overflow-hidden bg-stone-100 rounded-xs">
                  <img
                    src={story.imageUrl}
                    alt={story.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    loading="lazy"
                  />
                </div>

                {/* Details */}
                <div className="flex flex-col justify-between flex-1">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#7B1113] bg-[#7B1113]/10 px-1.5 py-0.5 rounded">
                        {story.category}
                      </span>
                      <span className="text-[11px] text-stone-400">
                        {story.readTime}
                      </span>
                    </div>

                    <h4 className="font-serif-headline text-sm sm:text-base font-bold text-stone-900 group-hover:text-[#7B1113] leading-snug line-clamp-2 transition">
                      {story.title}
                    </h4>

                    <p className="text-xs text-stone-600 line-clamp-2 mt-1 font-serif-body">
                      {story.subtitle}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-stone-500 pt-2 mt-2 border-t border-stone-100">
                    <span className="truncate">{story.author.name}</span>
                    <span className="text-[#C5A059] font-medium group-hover:translate-x-1 transition flex items-center gap-0.5">
                      Read &rarr;
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
