import React, { useState } from 'react';
import { X, CheckCircle2 } from 'lucide-react';

interface EditorialPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'about' | 'policy' | 'contact' | 'privacy';
}

export const EditorialPolicyModal: React.FC<EditorialPolicyModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'about'
}) => {
  const [activeTab, setActiveTab] = useState<'about' | 'policy' | 'contact' | 'privacy'>(initialTab);
  const [contactSent, setContactSent] = useState(false);
  const [contactSubject, setContactSubject] = useState('');
  const [contactMessage, setContactMessage] = useState('');

  if (!isOpen) return null;

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSent(true);
    setTimeout(() => {
      setContactSent(false);
      onClose();
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-[#FAF9F6] border border-[#E5E0D8] rounded-lg max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-[#580C0E] text-white p-5 flex items-center justify-between border-b border-[#7B1113]">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8D39E]">
              Governance &amp; Transparency
            </span>
            <h3 className="font-serif-headline text-lg sm:text-xl font-bold">
              Veritas Catholic News Portal
            </h3>
          </div>
          <button onClick={onClose} className="text-stone-300 hover:text-white p-1 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Bar */}
        <div className="flex border-b border-stone-200 bg-stone-100 text-xs font-semibold uppercase tracking-wider overflow-x-auto">
          <button
            onClick={() => setActiveTab('about')}
            className={`px-4 py-3 border-b-2 transition whitespace-nowrap ${
              activeTab === 'about'
                ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            About Veritas
          </button>
          <button
            onClick={() => setActiveTab('policy')}
            className={`px-4 py-3 border-b-2 transition whitespace-nowrap ${
              activeTab === 'policy'
                ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            Editorial Policy
          </button>
          <button
            onClick={() => setActiveTab('contact')}
            className={`px-4 py-3 border-b-2 transition whitespace-nowrap ${
              activeTab === 'contact'
                ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            Contact Desk
          </button>
          <button
            onClick={() => setActiveTab('privacy')}
            className={`px-4 py-3 border-b-2 transition whitespace-nowrap ${
              activeTab === 'privacy'
                ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            Privacy &amp; Terms
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 font-serif-body text-stone-800 text-base leading-relaxed flex-1">
          {activeTab === 'about' && (
            <div className="space-y-4">
              <h4 className="font-serif-headline text-lg font-bold text-[#7B1113]">
                Our Mission: Veritas in Caritate (Truth in Charity)
              </h4>
              <p>
                <strong>Veritas Catholic News</strong> is an independent international Catholic digital news publication committed to providing fair, faithful, and comprehensive reportage of the Holy See, the Bishop of Rome, global dioceses, and humanitarian initiatives.
              </p>
              <p>
                Taking editorial and visual inspiration from the journalistic integrity of <em>Vatican News (vaticannews.va)</em>, we serve English-speaking Catholics, clergy, religious, and seekers worldwide with timely chronicles grounded in ecclesial communion.
              </p>
              <div className="bg-stone-50 border-l-3 border-[#C5A059] p-4 text-sm italic text-stone-700">
                &quot;To communicate with grace, to speak the truth in love, and to bear witness to the hope that does not disappoint.&quot;
              </div>
            </div>
          )}

          {activeTab === 'policy' && (
            <div className="space-y-4">
              <h4 className="font-serif-headline text-lg font-bold text-[#7B1113]">
                Editorial Integrity &amp; Canon Law Standards
              </h4>
              <p>
                Our reporting operates strictly under universal journalistic standards and the Magisterium of the Catholic Church.
              </p>
              <ul className="list-disc pl-5 space-y-2 text-sm text-stone-700">
                <li><strong>Accuracy &amp; Attribution:</strong> All statements by the Holy Father, Vatican dicasteries, and bishops conferences are verified against official Holy See Press Office transcripts.</li>
                <li><strong>Charity in Dialogue:</strong> In matters of theological commentary and synodal discussions, we uphold evangelical charity, avoiding sensationalism or partisan divisiveness.</li>
                <li><strong>Corrections Policy:</strong> If an error of fact occurs, it is rectified transparently with an editor’s note within 24 hours.</li>
                <li><strong>Photojournalism Ethics:</strong> Images must preserve contextual fidelity and religious reverence without misleading digital alteration.</li>
              </ul>
            </div>
          )}

          {activeTab === 'contact' && (
            <div className="space-y-4">
              <h4 className="font-serif-headline text-lg font-bold text-[#7B1113]">
                Reach Our News Desks
              </h4>
              <p className="text-sm">
                Have a news tip, press release, or pastoral inquiry? Reach out to our editors.
              </p>

              {contactSent ? (
                <div className="bg-emerald-50 text-emerald-800 border border-emerald-300 p-4 rounded text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                  <span>Your dispatch has been delivered to the newsroom desk. Thank you for your partnership.</span>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-3 font-sans text-xs">
                  <div>
                    <label className="block font-bold uppercase tracking-wider text-stone-600 mb-1">
                      Desk Subject
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Vatican Press Release / Editorial Inquiry"
                      value={contactSubject}
                      onChange={(e) => setContactSubject(e.target.value)}
                      className="w-full border border-stone-300 p-2 rounded focus:outline-none focus:border-[#7B1113]"
                    />
                  </div>
                  <div>
                    <label className="block font-bold uppercase tracking-wider text-stone-600 mb-1">
                      Your Message
                    </label>
                    <textarea
                      rows={4}
                      required
                      placeholder="Provide details or source documents..."
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      className="w-full border border-stone-300 p-2 rounded focus:outline-none focus:border-[#7B1113]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#7B1113] hover:bg-[#580C0E] text-white font-bold uppercase tracking-wider rounded transition"
                  >
                    Send to Newsroom
                  </button>
                </form>
              )}
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="space-y-4 text-sm text-stone-700">
              <h4 className="font-serif-headline text-lg font-bold text-[#7B1113]">
                Privacy Policy &amp; Terms of Use
              </h4>
              <p>
                We respect your personal privacy. Veritas Catholic News does not harvest, monetize, or sell reader emails, reading habits, or identifying data.
              </p>
              <p>
                Newsletter subscribers can cancel or modify preferences instantly through the unsubscribe link embedded in every email. Cookies are utilized strictly for user interface preferences (such as font size and reading background settings).
              </p>
              <p className="text-xs text-stone-500">
                All articles and materials are protected by international copyright law. Fair-use quotation is permitted with explicit credit and a canonical backlink to Veritas Catholic News.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-stone-100 p-4 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-stone-800 hover:bg-stone-900 text-white text-xs font-semibold uppercase tracking-wider rounded transition"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
