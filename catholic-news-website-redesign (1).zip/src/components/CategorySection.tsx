import React from 'react';
import { ArrowRight, Clock } from 'lucide-react';
import { Article, Category } from '../types';

interface CategorySectionProps {
  title: string;
  category: Category;
  description?: string;
  articles: Article[];
  onSelectArticle: (article: Article) => void;
  onSelectCategory: (category: Category) => void;
}

export const CategorySection: React.FC<CategorySectionProps> = ({
  title,
  category,
  description,
  articles,
  onSelectArticle,
  onSelectCategory,
}) => {
  if (articles.length === 0) return null;

  return (
    <section className="mb-12">
      {/* Section Header */}
      <div className="flex items-center justify-between border-b-2 border-[#7B1113] pb-2 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-[#C5A059]"></span>
            <h2 className="font-serif-headline text-lg sm:text-xl font-bold uppercase tracking-wider text-[#7B1113]">
              {title}
            </h2>
          </div>
          {description && (
            <p className="text-xs text-stone-500 font-serif-body italic mt-0.5">
              {description}
            </p>
          )}
        </div>
        
        <button
          onClick={() => onSelectCategory(category)}
          className="text-xs font-semibold text-[#7B1113] hover:text-[#580C0E] inline-flex items-center gap-1 uppercase tracking-wider transition"
        >
          <span>More in {category}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map((article) => (
          <article
            key={article.id}
            onClick={() => onSelectArticle(article)}
            className="bg-white border border-[#E5E0D8] flex flex-col hover:border-stone-400 hover:shadow-xs transition group cursor-pointer"
          >
            {/* Image Thumbnail */}
            <div className="aspect-16/10 bg-stone-100 overflow-hidden relative">
              <img
                src={article.imageUrl}
                alt={article.title}
                className="w-full h-full object-cover group-hover:scale-103 transition duration-400"
                loading="lazy"
              />
              <span className="absolute top-2 left-2 bg-[#7B1113] text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-xs">
                {article.category}
              </span>
            </div>

            {/* Content Details */}
            <div className="p-4 flex flex-col flex-1">
              <div className="flex items-center gap-2 text-[11px] text-stone-500 mb-1.5">
                <span className="flex items-center gap-1 text-[#7B1113] font-medium">
                  <Clock className="w-3 h-3" />
                  {article.readTime}
                </span>
                <span>•</span>
                <span>{new Date(article.publishedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
              </div>

              <h3 className="font-serif-headline text-base font-bold text-stone-900 group-hover:text-[#7B1113] leading-snug line-clamp-2 mb-2 transition">
                {article.title}
              </h3>

              <p className="font-serif-body text-xs text-stone-600 line-clamp-3 leading-relaxed mb-4 flex-1">
                {article.subtitle}
              </p>

              <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
                <span className="truncate max-w-[160px]">{article.author.name}</span>
                <span className="text-[#C5A059] font-medium group-hover:underline">
                  Full Story &rarr;
                </span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};
