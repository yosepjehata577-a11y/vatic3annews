import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';
import { BREAKING_NEWS } from '../data/newsData';

interface BreakingTickerProps {
  onSelectBreaking?: (text: string) => void;
}

export const BreakingTicker: React.FC<BreakingTickerProps> = ({ onSelectBreaking }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % BREAKING_NEWS.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? BREAKING_NEWS.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % BREAKING_NEWS.length);
  };

  return (
    <div className="bg-white border-b border-[#E5E0D8] text-xs py-2 px-4 shadow-2xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Badge */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="flex items-center gap-1.5 bg-[#7B1113] text-white px-2.5 py-1 rounded font-bold uppercase tracking-wider text-[11px]">
            <span className="w-2 h-2 rounded-full bg-red-300 animate-ping"></span>
            <span>Breaking Dispatches</span>
          </div>
        </div>

        {/* Center: Live headline */}
        <div 
          onClick={() => onSelectBreaking && onSelectBreaking(BREAKING_NEWS[currentIndex])}
          className="flex-1 overflow-hidden cursor-pointer group transition"
          title="Click to view breaking report"
        >
          <p className="truncate font-medium text-stone-800 group-hover:text-[#7B1113] transition">
            <span className="text-[#C5A059] font-bold mr-2">[{currentIndex + 1}/{BREAKING_NEWS.length}]</span>
            {BREAKING_NEWS[currentIndex]}
          </p>
        </div>

        {/* Right: Controls */}
        <div className="flex items-center gap-1 text-stone-500 flex-shrink-0">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-1 hover:text-stone-900 hover:bg-stone-100 rounded transition"
            title={isPlaying ? 'Pause ticker' : 'Resume ticker'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={handlePrev}
            className="p-1 hover:text-stone-900 hover:bg-stone-100 rounded transition"
            title="Previous alert"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleNext}
            className="p-1 hover:text-stone-900 hover:bg-stone-100 rounded transition"
            title="Next alert"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
