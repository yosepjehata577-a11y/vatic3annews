import React, { useState, useMemo } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { Article, Category } from '../types';
import { CATEGORIES } from '../data/newsData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  articles: Article[];
  onSelectArticle: (article: Article) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  articles,
  onSelectArticle
}) => {
  const [query, setQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState<Category>('All');

  const filteredArticles = useMemo(() => {
    return articles.filter((art) => {
      const matchesCat = selectedCat === 'All' || art.category === selectedCat;
      const q = query.toLowerCase().trim();
      if (!q) return matchesCat;
      const matchesText = 
        art.title.toLowerCase().includes(q) ||
        art.subtitle.toLowerCase().includes(q) ||
        art.leadParagraph.toLowerCase().includes(q) ||
        art.tags.some(t => t.toLowerCase().includes(q)) ||
        art.author.name.toLowerCase().includes(q);
      return matchesCat && matchesText;
    });
  }, [articles, query, selectedCat]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div 
        className="bg-white border border-[#E5E0D8] rounded-lg max-w-3xl w-full shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150 flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-stone-200 flex items-center gap-3 bg-[#FAF9F6]">
          <Search className="w-5 h-5 text-[#7B1113] flex-shrink-0" />
          <input
            type="text"
            placeholder="Search Vatican teachings, encyclicals, synodal reports, homilies..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent text-stone-900 placeholder:text-stone-400 font-serif-body text-base focus:outline-none"
          />
          {query && (
            <button 
              onClick={() => setQuery('')}
              className="text-stone-400 hover:text-stone-600 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-700 p-1 rounded hover:bg-stone-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Filters */}
        <div className="px-4 py-2.5 bg-stone-50 border-b border-stone-200 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-stone-400 font-medium">Filter:</span>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCat(cat)}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap font-medium transition ${
                selectedCat === cat
                  ? 'bg-[#7B1113] text-white font-bold'
                  : 'bg-white text-stone-600 hover:bg-stone-200 border border-stone-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results Count */}
        <div className="px-4 py-2 bg-stone-100 text-[11px] text-stone-500 uppercase tracking-wider font-semibold border-b border-stone-200 flex justify-between items-center">
          <span>{filteredArticles.length} Dispatches Found</span>
          {selectedCat !== 'All' && <span>Category: {selectedCat}</span>}
        </div>

        {/* Results List */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {filteredArticles.length === 0 ? (
            <div className="text-center py-12 text-stone-400">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-40 text-[#7B1113]" />
              <p className="font-serif-headline text-base text-stone-700">No Catholic reports match your query</p>
              <p className="text-xs text-stone-500 mt-1">Try keywords like &quot;Pope&quot;, &quot;Synod&quot;, &quot;Gospel&quot;, or clear your filter.</p>
            </div>
          ) : (
            filteredArticles.map((art) => (
              <div
                key={art.id}
                onClick={() => {
                  onSelectArticle(art);
                  onClose();
                }}
                className="flex items-start gap-3 p-3 bg-[#FAF9F6] hover:bg-white border border-transparent hover:border-stone-300 rounded cursor-pointer group transition"
              >
                <div className="w-20 h-16 sm:w-24 sm:h-18 flex-shrink-0 bg-stone-200 rounded overflow-hidden">
                  <img
                    src={art.imageUrl}
                    alt={art.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 text-[10px] uppercase font-bold text-[#7B1113] mb-0.5">
                    <span>{art.category}</span>
                    <span className="text-stone-300">•</span>
                    <span className="text-stone-400">{art.readTime}</span>
                  </div>
                  <h4 className="font-serif-headline text-sm font-bold text-stone-900 group-hover:text-[#7B1113] leading-snug line-clamp-1">
                    {art.title}
                  </h4>
                  <p className="text-xs text-stone-600 line-clamp-2 mt-0.5 font-serif-body">
                    {art.subtitle}
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-stone-400 group-hover:text-[#7B1113] group-hover:translate-x-1 transition self-center" />
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
