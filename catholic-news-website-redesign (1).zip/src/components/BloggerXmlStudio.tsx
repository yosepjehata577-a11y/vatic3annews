import React, { useState, useMemo } from 'react';
import { 
  Download, 
  Copy, 
  Check, 
  FileCode, 
  ShieldCheck, 
  HelpCircle, 
  Sliders, 
  Search, 
  Code2, 
  Layers, 
  ArrowLeft,
  AlertTriangle
} from 'lucide-react';
import { BLOGGER_XML_TEMPLATE_CODE, TEMPLATE_AUDIT_PHASES } from '../data/bloggerXmlTemplate';

interface BloggerXmlStudioProps {
  onClose: () => void;
}

export const BloggerXmlStudio: React.FC<BloggerXmlStudioProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'code' | 'audit' | 'customizer' | 'install'>('code');
  const [copied, setCopied] = useState(false);
  const [xmlSearch, setXmlSearch] = useState('');
  const [validationResult, setValidationResult] = useState<{
    tested: boolean;
    valid: boolean;
    errors: string[];
    details: string;
  }>({
    tested: false,
    valid: true,
    errors: [],
    details: ''
  });

  // Customizer state
  const [customTitle, setCustomTitle] = useState('VERITAS CATHOLIC NEWS');
  const [customTagline, setCustomTagline] = useState('International Voice of the Catholic Church • Truth in Charity');
  const [customColor, setCustomColor] = useState('#7B1113');

  // Compute customized XML if modified
  const currentXmlCode = useMemo(() => {
    let code = BLOGGER_XML_TEMPLATE_CODE;
    if (customTitle !== 'VERITAS CATHOLIC NEWS') {
      code = code.replace(/VERITAS CATHOLIC NEWS/g, customTitle);
    }
    if (customTagline !== 'International Voice of the Catholic Church • Truth in Charity') {
      code = code.replace(/International Voice of the Catholic Church &#8226; Truth in Charity/g, customTagline);
    }
    if (customColor !== '#7B1113') {
      code = code.replace(/--primary: #7B1113;/g, `--primary: ${customColor};`);
    }
    return code;
  }, [customTitle, customTagline, customColor]);

  // Handle live DOM XML parser validation
  const handleValidateXml = () => {
    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(currentXmlCode, 'text/xml');
      const parseError = xmlDoc.getElementsByTagName('parsererror');

      if (parseError.length > 0) {
        setValidationResult({
          tested: true,
          valid: false,
          errors: [parseError[0].textContent || 'Unknown XML parse error'],
          details: 'The XML document contains syntax discrepancies.'
        });
      } else {
        const rootTag = xmlDoc.documentElement.nodeName;
        const bSections = xmlDoc.getElementsByTagName('b:section').length;
        const bWidgets = xmlDoc.getElementsByTagName('b:widget').length;

        setValidationResult({
          tested: true,
          valid: true,
          errors: [],
          details: `XML Well-Formed & Verified: Root <${rootTag}> parsed successfully. Found ${bSections} <b:section> containers and ${bWidgets} Blogger widgets with 0 syntax errors.`
        });
      }
    } catch (err: any) {
      setValidationResult({
        tested: true,
        valid: false,
        errors: [err.message || 'Parser exception'],
        details: 'XML validation failed.'
      });
    }
  };

  // Handle Download of .xml file
  const handleDownload = () => {
    const blob = new Blob([currentXmlCode], { type: 'application/xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'veritas-catholic-news-vatican-template.xml';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Handle Copy to clipboard
  const handleCopy = () => {
    navigator.clipboard.writeText(currentXmlCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Filtered code lines for search
  const xmlLines = useMemo(() => {
    return currentXmlCode.split('\n');
  }, [currentXmlCode]);

  return (
    <div className="bg-[#1C1917] text-stone-200 min-h-screen flex flex-col font-sans">
      
      {/* 1. Top Studio Bar */}
      <div className="bg-[#141210] border-b border-stone-800 px-4 py-3 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded transition flex items-center gap-1.5 text-xs font-semibold"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Return to Portal</span>
            </button>
            <div className="h-4 w-px bg-stone-700 hidden sm:block" />
            <div>
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-[#C5A059]" />
                <h2 className="font-serif-headline text-stone-100 font-bold text-sm sm:text-base">
                  Blogger XML Template Studio &amp; Architecture Suite
                </h2>
                <span className="bg-[#7B1113] text-white text-[10px] font-mono px-2 py-0.5 rounded font-bold">
                  Blogger V3 XML
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Engineered for Vatican News editorial aesthetic &amp; Google Core Web Vitals
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleValidateXml}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded border border-stone-700 transition"
              title="Test well-formedness using DOMParser"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Validate XML</span>
            </button>

            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#580C0E] hover:bg-[#7B1113] text-white text-xs font-semibold rounded transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied XML!' : 'Copy XML'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#C5A059] hover:bg-[#E8D39E] text-stone-950 text-xs font-bold rounded transition shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .XML</span>
            </button>
          </div>

        </div>
      </div>

      {/* Validation Banner if tested */}
      {validationResult.tested && (
        <div className={`px-4 py-2.5 text-xs border-b ${
          validationResult.valid 
            ? 'bg-emerald-950/80 border-emerald-800 text-emerald-200' 
            : 'bg-rose-950/80 border-rose-800 text-rose-200'
        }`}>
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              {validationResult.valid ? (
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400" />
              )}
              <span className="font-semibold">{validationResult.details}</span>
            </div>
            <button 
              onClick={() => setValidationResult({ ...validationResult, tested: false })}
              className="text-stone-400 hover:text-white"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* 2. Studio Tabs */}
      <div className="bg-[#171513] border-b border-stone-800 px-4">
        <div className="max-w-7xl mx-auto flex gap-4 text-xs font-semibold uppercase tracking-wider overflow-x-auto">
          <button
            onClick={() => setActiveTab('code')}
            className={`py-3 border-b-2 flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'code'
                ? 'border-[#C5A059] text-[#C5A059] font-bold'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>XML Template Code ({xmlLines.length} Lines)</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`py-3 border-b-2 flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'audit'
                ? 'border-[#C5A059] text-[#C5A059] font-bold'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Phases 1–5 Technical Audit &amp; Architecture</span>
          </button>

          <button
            onClick={() => setActiveTab('customizer')}
            className={`py-3 border-b-2 flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'customizer'
                ? 'border-[#C5A059] text-[#C5A059] font-bold'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Live Template Customizer</span>
          </button>

          <button
            onClick={() => setActiveTab('install')}
            className={`py-3 border-b-2 flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'install'
                ? 'border-[#C5A059] text-[#C5A059] font-bold'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Blogger Installation &amp; Rollback Guide</span>
          </button>
        </div>
      </div>

      {/* 3. Studio Main Work Area */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        
        {/* TAB 1: XML CODE VIEWER */}
        {activeTab === 'code' && (
          <div className="space-y-4">
            {/* Search within code */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#171513] p-3 rounded border border-stone-800">
              <div className="flex items-center gap-2 w-full sm:w-80">
                <Search className="w-4 h-4 text-stone-500" />
                <input
                  type="text"
                  placeholder="Find tags (e.g. b:skin, b:section, Blog1, NewsArticle)..."
                  value={xmlSearch}
                  onChange={(e) => setXmlSearch(e.target.value)}
                  className="bg-stone-900 border border-stone-700 px-2 py-1 text-xs rounded w-full text-stone-200 focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <div className="flex items-center gap-3 text-xs text-stone-400">
                <span>Blogger Namespaces: <strong>xmlns:b</strong>, <strong>xmlns:data</strong>, <strong>xmlns:expr</strong></span>
                <span>•</span>
                <span className="text-emerald-400 font-medium">UTF-8 Encoded</span>
              </div>
            </div>

            {/* Code container with line numbers */}
            <div className="bg-[#121110] border border-stone-800 rounded-lg overflow-hidden shadow-2xl">
              <div className="bg-[#0D0C0B] px-4 py-2 border-b border-stone-800 flex items-center justify-between text-xs font-mono text-stone-400">
                <span>veritas-catholic-news-template.xml</span>
                <span>Lines: 1 – {xmlLines.length}</span>
              </div>

              <div className="max-h-[650px] overflow-auto p-4 font-mono text-xs leading-5">
                <pre className="text-stone-300">
                  <code>
                    {xmlLines.map((line, idx) => {
                      const lineNum = idx + 1;
                      const isMatch = xmlSearch && line.toLowerCase().includes(xmlSearch.toLowerCase());
                      return (
                        <div 
                          key={lineNum} 
                          className={`flex hover:bg-stone-800/40 ${isMatch ? 'bg-[#7B1113]/40' : ''}`}
                        >
                          <span className="w-12 select-none text-stone-600 text-right pr-4 flex-shrink-0">
                            {lineNum}
                          </span>
                          <span className="text-stone-300 whitespace-pre overflow-x-auto">
                            {line}
                          </span>
                        </div>
                      );
                    })}
                  </code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: AUDIT & ARCHITECTURE (PHASES 1-5) */}
        {activeTab === 'audit' && (
          <div className="space-y-6">
            <div className="bg-[#171513] p-6 rounded-lg border border-stone-800">
              <h3 className="font-serif-headline text-xl font-bold text-[#E8D39E] mb-2">
                Template Transformation &amp; Architecture Audit Report
              </h3>
              <p className="text-stone-400 text-sm font-serif-body leading-relaxed">
                A comprehensive technical evaluation detailing how legacy Blogger XML structures were systematically refactored into a high-authority international Catholic news portal inspired by Vatican News (vaticannews.va).
              </p>
            </div>

            <div className="grid grid-cols-1 gap-6">
              {TEMPLATE_AUDIT_PHASES.map((phase, idx) => (
                <div 
                  key={idx}
                  className="bg-[#171513] border border-stone-800 rounded-lg p-5 shadow-xs"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-800 mb-4">
                    <h4 className="font-serif-headline text-lg font-bold text-stone-100">
                      {phase.title}
                    </h4>
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-[#7B1113]/30 text-[#E8D39E] border border-[#7B1113]">
                      {phase.badge}
                    </span>
                  </div>

                  <p className="text-stone-300 text-xs font-medium mb-4">
                    {phase.summary}
                  </p>

                  <ul className="space-y-2 text-xs text-stone-400 font-serif-body">
                    {phase.details.map((item, dIdx) => (
                      <li key={dIdx} className="flex items-start gap-2">
                        <span className="text-[#C5A059] font-bold mt-0.5">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: LIVE TEMPLATE CUSTOMIZER */}
        {activeTab === 'customizer' && (
          <div className="bg-[#171513] border border-stone-800 rounded-lg p-6 space-y-6">
            <div>
              <h3 className="font-serif-headline text-xl font-bold text-[#E8D39E] mb-1">
                Live Blogger XML Parameter Customizer
              </h3>
              <p className="text-xs text-stone-400">
                Modify your publication credentials and branding colors. The XML code updates automatically in memory and is immediately downloadable.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-400 mb-1">
                    Publication Masthead Name
                  </label>
                  <input
                    type="text"
                    value={customTitle}
                    onChange={(e) => setCustomTitle(e.target.value)}
                    className="w-full bg-stone-900 border border-stone-700 p-2.5 rounded text-sm text-stone-100 focus:outline-none focus:border-[#C5A059]"
                  />
                  <span className="text-[11px] text-stone-500 mt-0.5 block">
                    Rendered in Header1 widget and primary metadata title tags.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-400 mb-1">
                    Publication Editorial Tagline
                  </label>
                  <input
                    type="text"
                    value={customTagline}
                    onChange={(e) => setCustomTagline(e.target.value)}
                    className="w-full bg-stone-900 border border-stone-700 p-2.5 rounded text-sm text-stone-100 focus:outline-none focus:border-[#C5A059]"
                  />
                  <span className="text-[11px] text-stone-500 mt-0.5 block">
                    Appears below the masthead and inside OpenGraph site descriptions.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-400 mb-1">
                    Primary Vatican Color Accent
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={customColor}
                      onChange={(e) => setCustomColor(e.target.value)}
                      className="w-10 h-10 rounded border border-stone-700 bg-transparent cursor-pointer"
                    />
                    <input
                      type="text"
                      value={customColor}
                      onChange={(e) => setCustomColor(e.target.value)}
                      className="w-32 bg-stone-900 border border-stone-700 p-2 text-xs font-mono rounded text-stone-100"
                    />
                    <button
                      onClick={() => setCustomColor('#7B1113')}
                      className="text-xs text-stone-400 hover:text-white underline"
                    >
                      Reset to Vatican Burgundy
                    </button>
                  </div>
                </div>
              </div>

              {/* Preview Box */}
              <div className="bg-[#FAF9F6] text-stone-900 p-6 rounded border border-stone-300 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#7B1113] block mb-2">
                    Live Header Preview
                  </span>
                  <div className="text-center py-4 border-y border-stone-200">
                    <div 
                      className="w-8 h-8 rounded-full text-white mx-auto mb-2 flex items-center justify-center font-bold text-xs"
                      style={{ backgroundColor: customColor }}
                    >
                      <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                        <path d="M11 2h2v6h5v2h-5v4h3v2h-3v6h-2v-6H8v-2h3v-4H6V8h5V2z"/>
                      </svg>
                    </div>
                    <h2 
                      className="font-masthead text-xl font-bold uppercase tracking-wider"
                      style={{ color: customColor }}
                    >
                      {customTitle}
                    </h2>
                    <p className="font-serif-headline text-xs text-stone-600 italic mt-1">
                      {customTagline}
                    </p>
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    onClick={handleDownload}
                    className="px-4 py-2 bg-[#7B1113] hover:bg-[#580C0E] text-white text-xs font-bold uppercase tracking-wider rounded transition"
                  >
                    Export Customized XML
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 4: BLOGGER INSTALLATION & ROLLBACK GUIDE */}
        {activeTab === 'install' && (
          <div className="bg-[#171513] border border-stone-800 rounded-lg p-6 space-y-6">
            <div>
              <h3 className="font-serif-headline text-xl font-bold text-[#E8D39E] mb-1">
                Blogger Installation, Deployment &amp; Rollback Protocols
              </h3>
              <p className="text-xs text-stone-400">
                Follow this safe 5-step deployment procedure to install the Vatican News template on your Blogger/Blogspot blog without losing widgets or existing posts.
              </p>
            </div>

            <div className="space-y-4">
              
              {/* Step 1 */}
              <div className="bg-stone-900 p-4 rounded border border-stone-800 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-[#7B1113] text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                  1
                </div>
                <div>
                  <h4 className="font-bold text-stone-200 text-sm mb-1">
                    Crucial Step: Create a Backup of Your Current Template
                  </h4>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Open your <strong>Blogger Dashboard</strong> (<a href="https://www.blogger.com" target="_blank" rel="noopener noreferrer" className="text-[#C5A059] underline">blogger.com</a>) and click <strong>Theme</strong> in the left sidebar menu. Next to the orange &quot;Customize&quot; button, click the <strong>dropdown arrow</strong> and select <strong>Backup</strong>. Download the current XML file to your computer. This ensures 100% reversible rollback if ever desired.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="bg-stone-900 p-4 rounded border border-stone-800 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-[#7B1113] text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                  2
                </div>
                <div>
                  <h4 className="font-bold text-stone-200 text-sm mb-1">
                    Access the HTML Editor
                  </h4>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Click the dropdown arrow next to &quot;Customize&quot; again and select <strong>Edit HTML</strong>. You will see Blogger&#39;s built-in code editor.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="bg-stone-900 p-4 rounded border border-stone-800 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-[#7B1113] text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                  3
                </div>
                <div>
                  <h4 className="font-bold text-stone-200 text-sm mb-1">
                    Replace Existing Code with Revised XML
                  </h4>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Click inside the Blogger code editor, press <kbd className="bg-stone-800 px-1 py-0.5 rounded text-[10px]">Ctrl+A</kbd> (or <kbd className="bg-stone-800 px-1 py-0.5 rounded text-[10px]">Cmd+A</kbd> on Mac) to select all existing code, and press Delete. Then click <strong>&quot;Copy XML&quot;</strong> in this studio and paste it directly into Blogger&#39;s editor.
                  </p>
                </div>
              </div>

              {/* Step 4 */}
              <div className="bg-stone-900 p-4 rounded border border-stone-800 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-[#7B1113] text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                  4
                </div>
                <div>
                  <h4 className="font-bold text-stone-200 text-sm mb-1">
                    Save and Inspect Live
                  </h4>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Click the <strong>Save (Disk)</strong> icon in the top right of Blogger&#39;s editor. Blogger will validate the XML structure. Once &quot;Update Successful&quot; displays, click <strong>View Blog</strong> to enjoy your new Vatican News-inspired editorial portal!
                  </p>
                </div>
              </div>

              {/* Step 5 */}
              <div className="bg-stone-900 p-4 rounded border border-stone-800 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-[#C5A059] text-stone-950 flex items-center justify-center font-bold text-sm flex-shrink-0">
                  5
                </div>
                <div>
                  <h4 className="font-bold text-stone-200 text-sm mb-1">
                    Label Setup for Category Pages
                  </h4>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Assign your Blogger post labels to match the 10 editorial desks: <code>Vatican</code>, <code>Pope</code>, <code>Church</code>, <code>World</code>, <code>Faith</code>, <code>Prayer</code>, <code>Gospel</code>, <code>Catholic Life</code>, <code>Culture</code>, and <code>Analysis</code>. Blogger automatically generates the category feeds.
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>

    </div>
  );
};
