import React, { useState } from 'react';
import { BookOpen, Calendar, Sparkles, Heart, ChevronRight, X } from 'lucide-react';
import { LiturgicalDay } from '../types';

interface LiturgicalWidgetProps {
  liturgicalDay: LiturgicalDay;
  isOpenModal: boolean;
  onCloseModal: () => void;
  onOpenModal: () => void;
}

export const LiturgicalWidget: React.FC<LiturgicalWidgetProps> = ({
  liturgicalDay,
  isOpenModal,
  onCloseModal,
  onOpenModal
}) => {
  const [activeTab, setActiveTab] = useState<'gospel' | 'first' | 'psalm' | 'saint' | 'papal'>('gospel');

  return (
    <>
      {/* 1. Sidebar Card Widget */}
      <div className="bg-white border border-[#E5E0D8] p-5 shadow-xs mb-8 relative overflow-hidden">
        {/* Top gold bar */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#7B1113] via-[#C5A059] to-[#7B1113]" />

        <div className="flex items-center justify-between pb-3 border-b border-stone-200 mb-4">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#C5A059]" />
            <h3 className="font-serif-headline text-base font-bold uppercase tracking-wider text-[#7B1113]">
              Daily Liturgical Life
            </h3>
          </div>
          <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-stone-100 text-stone-700 border border-stone-200">
            {liturgicalDay.colorName}
          </span>
        </div>

        {/* Season & Feast */}
        <div className="mb-4">
          <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">
            {liturgicalDay.liturgicalSeason}
          </span>
          <h4 className="font-serif-headline text-sm font-bold text-stone-900 mt-0.5">
            {liturgicalDay.feastName}
          </h4>
        </div>

        {/* Saint of the day highlight */}
        <div className="bg-[#FAF7F2] p-3 rounded border border-[#E8D39E]/50 mb-4">
          <div className="flex items-center gap-1.5 text-xs font-bold text-[#7B1113] mb-1">
            <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>Saint of the Day</span>
          </div>
          <p className="font-serif-headline font-semibold text-stone-900 text-xs">
            {liturgicalDay.saintOfTheDay.name}
          </p>
          <p className="text-[11px] text-stone-600 line-clamp-2 mt-1">
            {liturgicalDay.saintOfTheDay.bio}
          </p>
        </div>

        {/* Today's Gospel excerpt */}
        <div className="space-y-1 mb-4">
          <span className="text-[11px] font-bold text-stone-600 uppercase tracking-wide">
            Today&#39;s Gospel Proclamation
          </span>
          <p className="text-xs font-semibold text-[#7B1113] font-mono">
            {liturgicalDay.readings.gospel.citation}
          </p>
          <blockquote className="text-xs text-stone-700 font-serif-body italic line-clamp-3 bg-stone-50 p-2 border-l-2 border-[#C5A059]">
            {liturgicalDay.readings.gospel.excerpt}
          </blockquote>
        </div>

        {/* Action Button to Open Full Daily Mass Readings Modal */}
        <button
          onClick={onOpenModal}
          className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-[#7B1113] hover:bg-[#580C0E] text-white text-xs font-bold uppercase tracking-wider rounded transition"
        >
          <span>Full Lectionary Readings</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 2. Full Liturgy & Daily Readings Modal */}
      {isOpenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-[#FAF9F6] border border-[#E5E0D8] rounded-lg max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl animate-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="bg-[#580C0E] text-white p-5 flex items-center justify-between border-b border-[#7B1113]">
              <div>
                <div className="flex items-center gap-2 text-[#E8D39E] text-xs font-semibold uppercase tracking-wider mb-1">
                  <Calendar className="w-4 h-4" />
                  <span>{liturgicalDay.formattedDate}</span>
                  <span>•</span>
                  <span>{liturgicalDay.liturgicalSeason}</span>
                </div>
                <h3 className="font-serif-headline text-lg sm:text-xl font-bold">
                  {liturgicalDay.feastName}
                </h3>
              </div>
              <button
                onClick={onCloseModal}
                className="text-stone-300 hover:text-white p-1 rounded hover:bg-white/10 transition"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Navigation Tabs */}
            <div className="flex border-b border-stone-200 bg-stone-100 overflow-x-auto text-xs font-semibold uppercase tracking-wider">
              <button
                onClick={() => setActiveTab('gospel')}
                className={`px-4 py-2.5 transition whitespace-nowrap border-b-2 ${
                  activeTab === 'gospel'
                    ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                    : 'border-transparent text-stone-600 hover:text-stone-900'
                }`}
              >
                Gospel
              </button>
              <button
                onClick={() => setActiveTab('first')}
                className={`px-4 py-2.5 transition whitespace-nowrap border-b-2 ${
                  activeTab === 'first'
                    ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                    : 'border-transparent text-stone-600 hover:text-stone-900'
                }`}
              >
                First Reading
              </button>
              <button
                onClick={() => setActiveTab('psalm')}
                className={`px-4 py-2.5 transition whitespace-nowrap border-b-2 ${
                  activeTab === 'psalm'
                    ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                    : 'border-transparent text-stone-600 hover:text-stone-900'
                }`}
              >
                Responsorial Psalm
              </button>
              <button
                onClick={() => setActiveTab('saint')}
                className={`px-4 py-2.5 transition whitespace-nowrap border-b-2 ${
                  activeTab === 'saint'
                    ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                    : 'border-transparent text-stone-600 hover:text-stone-900'
                }`}
              >
                Saint of the Day
              </button>
              <button
                onClick={() => setActiveTab('papal')}
                className={`px-4 py-2.5 transition whitespace-nowrap border-b-2 ${
                  activeTab === 'papal'
                    ? 'border-[#7B1113] text-[#7B1113] bg-white font-bold'
                    : 'border-transparent text-stone-600 hover:text-stone-900'
                }`}
              >
                Papal Intention
              </button>
            </div>

            {/* Modal Content Body */}
            <div className="p-6 overflow-y-auto space-y-4 flex-1">
              
              {activeTab === 'gospel' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#7B1113]">
                      The Holy Gospel According to Saint John
                    </span>
                    <span className="text-xs font-mono font-semibold bg-stone-200/70 px-2 py-0.5 rounded">
                      {liturgicalDay.readings.gospel.citation}
                    </span>
                  </div>
                  <div className="font-serif-body text-base sm:text-lg text-stone-800 leading-relaxed bg-white p-5 border border-stone-200 rounded-sm shadow-2xs">
                    <p className="italic text-stone-500 mb-3 text-sm">
                      A reading from the holy Gospel according to John:
                    </p>
                    <p>{liturgicalDay.readings.gospel.excerpt}</p>
                    <p className="text-xs font-semibold uppercase text-stone-500 mt-4 text-right">
                      The Gospel of the Lord — Praise to you, Lord Jesus Christ.
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'first' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#7B1113]">
                      First Reading
                    </span>
                    <span className="text-xs font-mono font-semibold bg-stone-200/70 px-2 py-0.5 rounded">
                      {liturgicalDay.readings.firstReading.citation}
                    </span>
                  </div>
                  <div className="font-serif-body text-base sm:text-lg text-stone-800 leading-relaxed bg-white p-5 border border-stone-200 rounded-sm">
                    <p>{liturgicalDay.readings.firstReading.excerpt}</p>
                    <p className="text-xs font-semibold uppercase text-stone-500 mt-4 text-right">
                      The Word of the Lord — Thanks be to God.
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'psalm' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#7B1113]">
                      Responsorial Psalm
                    </span>
                    <span className="text-xs font-mono font-semibold bg-stone-200/70 px-2 py-0.5 rounded">
                      {liturgicalDay.readings.responsorialPsalm.citation}
                    </span>
                  </div>
                  <div className="bg-[#FAF7F2] p-4 border-l-4 border-[#C5A059] rounded-xs">
                    <span className="text-xs uppercase font-bold text-stone-500 block">Response:</span>
                    <p className="font-serif-headline text-base font-bold text-[#7B1113]">
                      {liturgicalDay.readings.responsorialPsalm.response}
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'saint' && (
                <div className="space-y-4">
                  <div className="bg-white p-5 border border-stone-200 rounded">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#C5A059] block mb-1">
                      {liturgicalDay.saintOfTheDay.title}
                    </span>
                    <h4 className="font-serif-headline text-xl font-bold text-stone-900 mb-3">
                      {liturgicalDay.saintOfTheDay.name}
                    </h4>
                    <p className="font-serif-body text-stone-700 text-base leading-relaxed mb-4">
                      {liturgicalDay.saintOfTheDay.bio}
                    </p>
                    <div className="text-xs text-stone-500 border-t border-stone-200 pt-3">
                      <strong>Patronage:</strong> {liturgicalDay.saintOfTheDay.patronage}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'papal' && (
                <div className="space-y-4">
                  <div className="bg-white p-5 border border-stone-200 rounded">
                    <div className="flex items-center gap-2 text-[#7B1113] text-xs font-bold uppercase tracking-wider mb-2">
                      <Heart className="w-4 h-4 fill-current text-red-500" />
                      <span>Holy Father&#39;s Universal Prayer Intention ({liturgicalDay.papalIntention.month})</span>
                    </div>
                    <h4 className="font-serif-headline text-lg font-bold text-stone-900 mb-2">
                      {liturgicalDay.papalIntention.title}
                    </h4>
                    <p className="font-serif-body text-stone-700 text-base leading-relaxed italic bg-stone-50 p-4 border-l-3 border-[#7B1113]">
                      &quot;{liturgicalDay.papalIntention.description}&quot;
                    </p>
                    <p className="text-xs text-stone-500 mt-3">
                      Entrusted to the Pope&#39;s Worldwide Prayer Network (Apostleship of Prayer).
                    </p>
                  </div>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="bg-stone-100 p-4 border-t border-stone-200 flex justify-end">
              <button
                onClick={onCloseModal}
                className="px-4 py-2 bg-stone-800 hover:bg-stone-900 text-white text-xs font-semibold uppercase tracking-wider rounded transition"
              >
                Close Readings
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
