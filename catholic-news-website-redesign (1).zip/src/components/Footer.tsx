import React from 'react';
import { ArrowUp, BookOpen, Radio, Mail } from 'lucide-react';
import { Category } from '../types';

interface FooterProps {
  onSelectCategory: (category: Category) => void;
  onOpenPolicyModal: (tab?: 'about' | 'policy' | 'contact' | 'privacy') => void;
  onOpenAudio: () => void;
  onOpenLiturgyModal: () => void;
  onOpenNewsletter: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectCategory,
  onOpenPolicyModal,
  onOpenAudio,
  onOpenLiturgyModal,
  onOpenNewsletter
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#171513] text-[#D6D3D1] border-t-4 border-[#7B1113] pt-14 pb-8 text-sm">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Top Section: Brand + Newsletter Callout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-12 border-b border-stone-800">
          
          {/* Brand & Mission */}
          <div className="lg:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-[#7B1113] text-white flex items-center justify-center font-bold text-xs">
                {/* Cross emblem */}
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M11 2h2v6h5v2h-5v4h3v2h-3v6h-2v-6H8v-2h3v-4H6V8h5V2z"/>
                </svg>
              </div>
              <h2 className="font-masthead text-xl font-bold tracking-wider text-white uppercase">
                VERITAS CATHOLIC NEWS
              </h2>
            </div>
            
            <p className="font-serif-body text-stone-400 text-sm leading-relaxed max-w-md">
              An independent international Catholic publication offering truthful, balanced, and prayerful coverage of the Holy See, the universal Church, liturgical traditions, and global human dignity. Inspired by Vatican News editorial standards.
            </p>

            <div className="text-xs text-stone-500 pt-2 flex flex-wrap gap-4">
              <span>Truth in Charity</span>
              <span>•</span>
              <span>Veritas in Caritate</span>
              <span>•</span>
              <span>Ad Maiorem Dei Gloriam</span>
            </div>
          </div>

          {/* Quick Newsletter Inscription */}
          <div className="lg:col-span-7 bg-stone-900/80 p-6 rounded border border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#C5A059] flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5" />
                <span>Daily Vatican Dispatches</span>
              </span>
              <h3 className="font-serif-headline text-base font-bold text-white">
                Subscribe to Morning Ecclesial Briefings
              </h3>
              <p className="text-xs text-stone-400">
                Receive the Holy Father&#39;s speeches, daily Gospel reflections, and breaking reports.
              </p>
            </div>
            <button
              onClick={onOpenNewsletter}
              className="px-5 py-2.5 bg-[#7B1113] hover:bg-[#9B1B1E] text-white text-xs font-bold uppercase tracking-wider rounded transition whitespace-nowrap shadow-xs"
            >
              Subscribe Free
            </button>
          </div>

        </div>

        {/* Middle Section: Categorized Nav Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-10 border-b border-stone-800 text-xs">
          
          {/* Col 1: Editorial Topics */}
          <div>
            <h4 className="font-serif-headline text-sm font-bold uppercase tracking-wider text-[#C5A059] mb-4">
              Editorial Desks
            </h4>
            <ul className="space-y-2">
              {['Vatican', 'Pope', 'Church', 'World', 'Analysis'].map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => {
                      onSelectCategory(cat as Category);
                      window.scrollTo({ top: 300, behavior: 'smooth' });
                    }}
                    className="text-stone-400 hover:text-white transition"
                  >
                    {cat} Dispatches
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 2: Faith & Devotion */}
          <div>
            <h4 className="font-serif-headline text-sm font-bold uppercase tracking-wider text-[#C5A059] mb-4">
              Faith &amp; Devotion
            </h4>
            <ul className="space-y-2">
              {['Faith', 'Prayer', 'Gospel', 'Catholic Life', 'Culture'].map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => {
                      onSelectCategory(cat as Category);
                      window.scrollTo({ top: 300, behavior: 'smooth' });
                    }}
                    className="text-stone-400 hover:text-white transition"
                  >
                    {cat}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Media & Liturgy */}
          <div>
            <h4 className="font-serif-headline text-sm font-bold uppercase tracking-wider text-[#C5A059] mb-4">
              Liturgical Media
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={onOpenAudio} className="text-stone-400 hover:text-white flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-red-400" />
                  <span>Vatican Radio Broadcast</span>
                </button>
              </li>
              <li>
                <button onClick={onOpenLiturgyModal} className="text-stone-400 hover:text-white flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Daily Lectionary Readings</span>
                </button>
              </li>
              <li>
                <button onClick={onOpenLiturgyModal} className="text-stone-400 hover:text-white">
                  Saint of the Day
                </button>
              </li>
              <li>
                <button onClick={onOpenLiturgyModal} className="text-stone-400 hover:text-white">
                  Pope&#39;s Monthly Intention
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Publication Governance */}
          <div>
            <h4 className="font-serif-headline text-sm font-bold uppercase tracking-wider text-[#C5A059] mb-4">
              Governance &amp; Trust
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onOpenPolicyModal('about')} className="text-stone-400 hover:text-white">
                  About Veritas
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicyModal('policy')} className="text-stone-400 hover:text-white">
                  Editorial Standards
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicyModal('contact')} className="text-stone-400 hover:text-white">
                  Contact Newsroom
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicyModal('privacy')} className="text-stone-400 hover:text-white">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicyModal('privacy')} className="text-stone-400 hover:text-white">
                  Terms of Service
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Back to top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div>
            &copy; {new Date().getFullYear()} Veritas Catholic News. All rights reserved. English-language international edition.
          </div>
          
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1 text-stone-400 hover:text-white transition"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};
