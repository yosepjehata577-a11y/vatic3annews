import React, { useState } from 'react';
import { Mail, CheckCircle2, X, ShieldCheck } from 'lucide-react';

interface NewsletterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewsletterModal: React.FC<NewsletterModalProps> = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState('');
  const [frequency, setFrequency] = useState<'daily' | 'weekly' | 'breaking'>('daily');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white border border-[#E5E0D8] rounded-lg max-w-md w-full shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-[#580C0E] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-[#C5A059]" />
            <h3 className="font-serif-headline text-lg font-bold">
              Veritas Vatican Briefing
            </h3>
          </div>
          <button onClick={onClose} className="text-stone-300 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="text-center py-6 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto animate-bounce" />
              <h4 className="font-serif-headline text-xl font-bold text-stone-900">
                Welcome to Veritas Dispatch
              </h4>
              <p className="text-xs text-stone-600">
                A confirmation has been recorded for <strong className="text-stone-800">{email}</strong>. You will receive our next Catholic editorial dispatch.
              </p>
              <div className="pt-4">
                <button
                  onClick={() => {
                    setSubmitted(false);
                    onClose();
                  }}
                  className="px-4 py-2 bg-[#7B1113] hover:bg-[#580C0E] text-white text-xs font-bold uppercase tracking-wider rounded transition"
                >
                  Return to Portal
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="font-serif-body text-sm text-stone-700 leading-relaxed">
                Stay anchored in Church teaching and global Vatican reporting. Receive daily papal addresses, liturgical meditations, and world mission dispatches.
              </p>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="name@archdiocese.org"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-stone-300 p-2.5 rounded text-sm focus:outline-none focus:border-[#7B1113]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
                  Delivery Frequency
                </label>
                <div className="space-y-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer p-2 rounded hover:bg-stone-50 border border-stone-200">
                    <input
                      type="radio"
                      name="freq"
                      checked={frequency === 'daily'}
                      onChange={() => setFrequency('daily')}
                      className="accent-[#7B1113]"
                    />
                    <div>
                      <span className="font-bold text-stone-800">Daily Morning Briefing</span>
                      <p className="text-stone-500 text-[11px]">Vatican news, Daily Mass readings &amp; saint of the day.</p>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer p-2 rounded hover:bg-stone-50 border border-stone-200">
                    <input
                      type="radio"
                      name="freq"
                      checked={frequency === 'weekly'}
                      onChange={() => setFrequency('weekly')}
                      className="accent-[#7B1113]"
                    />
                    <div>
                      <span className="font-bold text-stone-800">Weekly Sunday Chronicle</span>
                      <p className="text-stone-500 text-[11px]">Pope&#39;s Angelus, Sunday homily summary &amp; in-depth analysis.</p>
                    </div>
                  </label>
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-stone-500 pt-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Zero spam. Respects pontifical communication ethics. Unsubscribe at any time.</span>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#7B1113] hover:bg-[#580C0E] text-white text-xs font-bold uppercase tracking-wider rounded transition shadow-sm"
              >
                Confirm Free Subscription
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
