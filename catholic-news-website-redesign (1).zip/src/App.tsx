import { useState } from 'react';
import { 
  CATEGORIES, 
  ARTICLES, 
  CURRENT_LITURGICAL_DAY 
} from './data/newsData';
import { Article, Category } from './types';
import { Header } from './components/Header';
import { BreakingTicker } from './components/BreakingTicker';
import { AudioBroadcastPlayer } from './components/AudioBroadcastPlayer';
import { HeroFeatured } from './components/HeroFeatured';
import { CategorySection } from './components/CategorySection';
import { LiturgicalWidget } from './components/LiturgicalWidget';
import { ArticleView } from './components/ArticleView';
import { SearchModal } from './components/SearchModal';
import { NewsletterModal } from './components/NewsletterModal';
import { EditorialPolicyModal } from './components/EditorialPolicyModal';
import { BloggerXmlStudio } from './components/BloggerXmlStudio';
import { Footer } from './components/Footer';
import { 
  TrendingUp, 
  Tag, 
  Mail, 
  Radio, 
  Code2
} from 'lucide-react';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<Category>('All');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [isXmlStudioOpen, setIsXmlStudioOpen] = useState(false);
  
  // Modals
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [liturgicalModalOpen, setLiturgicalModalOpen] = useState(false);
  const [newsletterModalOpen, setNewsletterModalOpen] = useState(false);
  const [policyModalOpen, setPolicyModalOpen] = useState(false);
  const [policyModalTab, setPolicyModalTab] = useState<'about' | 'policy' | 'contact' | 'privacy'>('about');
  const [audioPlayerOpen, setAudioPlayerOpen] = useState(false);

  // Derived articles
  const leadStory = ARTICLES.find((a) => a.isLeadStory) || ARTICLES[0];
  const secondaryStories = ARTICLES.filter((a) => a.isSecondaryLead).slice(0, 3);

  // Category subsets for homepage
  const vaticanAndPope = ARTICLES.filter((a) => a.category === 'Vatican' || a.category === 'Pope').slice(0, 3);
  const churchAndWorld = ARTICLES.filter((a) => a.category === 'Church' || a.category === 'World').slice(0, 3);
  const faithAndCulture = ARTICLES.filter((a) => 
    a.category === 'Faith' || 
    a.category === 'Gospel' || 
    a.category === 'Catholic Life' || 
    a.category === 'Culture' || 
    a.category === 'Analysis'
  ).slice(0, 3);

  // Filtered by selected category (when not 'All')
  const categoryArticles = ARTICLES.filter((a) => activeCategory === 'All' || a.category === activeCategory);

  // Popular posts for sidebar
  const popularArticles = [...ARTICLES].sort((a, b) => b.views - a.views).slice(0, 5);

  const handleSelectArticle = (article: Article) => {
    setSelectedArticle(article);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCategory = (cat: Category) => {
    setActiveCategory(cat);
    setSelectedArticle(null);
    window.scrollTo({ top: 200, behavior: 'smooth' });
  };

  const handleOpenPolicy = (tab: 'about' | 'policy' | 'contact' | 'privacy' = 'about') => {
    setPolicyModalTab(tab);
    setPolicyModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-[#1C1917] flex flex-col font-sans selection:bg-[#7B1113] selection:text-white">
      
      {/* 1. Header with masthead and navigation */}
      <Header
        activeCategory={activeCategory}
        onSelectCategory={handleSelectCategory}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenAudio={() => setAudioPlayerOpen(true)}
        onOpenLiturgyModal={() => setLiturgicalModalOpen(true)}
        liturgicalDay={CURRENT_LITURGICAL_DAY}
        isXmlStudioOpen={isXmlStudioOpen}
        onToggleXmlStudio={() => {
          setIsXmlStudioOpen(!isXmlStudioOpen);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenPolicyModal={() => handleOpenPolicy('policy')}
      />

      {/* 2. Audio Broadcast Player (Collapsible) */}
      <AudioBroadcastPlayer
        isOpen={audioPlayerOpen}
        onClose={() => setAudioPlayerOpen(false)}
      />

      {/* 3. Breaking News Ticker */}
      {!isXmlStudioOpen && (
        <BreakingTicker 
          onSelectBreaking={(text) => {
            const matched = ARTICLES.find(a => a.title.includes(text.slice(0, 20))) || ARTICLES[0];
            handleSelectArticle(matched);
          }}
        />
      )}

      {/* 4. MAIN CONTENT AREA */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8">
        
        {/* VIEW A: BLOGGER XML TEMPLATE STUDIO */}
        {isXmlStudioOpen ? (
          <BloggerXmlStudio onClose={() => setIsXmlStudioOpen(false)} />
        ) : selectedArticle ? (
          /* VIEW B: ARTICLE READING VIEW */
          <ArticleView
            article={selectedArticle}
            relatedArticles={ARTICLES.filter(a => a.id !== selectedArticle.id && (a.category === selectedArticle.category || a.tags.some(t => selectedArticle.tags.includes(t))))}
            prevArticle={ARTICLES[ARTICLES.findIndex(a => a.id === selectedArticle.id) - 1]}
            nextArticle={ARTICLES[ARTICLES.findIndex(a => a.id === selectedArticle.id) + 1]}
            onBack={() => setSelectedArticle(null)}
            onSelectArticle={handleSelectArticle}
            onSelectCategory={handleSelectCategory}
          />
        ) : (
          /* VIEW C: HOMEPAGE / CATEGORY ARCHIVE VIEW */
          <div>
            
            {/* Quick Banner Alert for Blogger XML Template Studio access */}
            <div className="bg-gradient-to-r from-[#580C0E] to-[#7B1113] text-white p-3.5 rounded-sm mb-8 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs border-l-4 border-[#C5A059]">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#C5A059] text-stone-950 flex items-center justify-center font-bold">
                  <Code2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-serif-headline text-sm font-bold text-[#E8D39E]">
                    Blogger XML Template Available for Deployment
                  </h4>
                  <p className="text-xs text-stone-200">
                    Inspected &amp; validated with clean Blogger V3 XML tags, Schema.org NewsArticle microdata, and mobile optimization.
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsXmlStudioOpen(true);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-4 py-1.5 bg-[#C5A059] hover:bg-[#E8D39E] text-stone-950 text-xs font-bold uppercase tracking-wider rounded transition whitespace-nowrap shadow-xs"
              >
                Open XML Studio
              </button>
            </div>

            {/* Layout Grid: 8 Cols Main Content + 4 Cols Editorial Sidebar */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left / Main Column (8 cols) */}
              <div className="lg:col-span-8">
                
                {activeCategory === 'All' ? (
                  <>
                    {/* Primary Hero & Secondary Editorial Cards */}
                    <HeroFeatured
                      leadStory={leadStory}
                      secondaryStories={secondaryStories}
                      onSelectArticle={handleSelectArticle}
                    />

                    {/* Category Block 1: Vatican & Pope */}
                    <CategorySection
                      title="Vatican &amp; Papal Teaching"
                      category="Vatican"
                      description="Apostolic constitutions, dicastery declarations, and General Audience catechesis."
                      articles={vaticanAndPope}
                      onSelectArticle={handleSelectArticle}
                      onSelectCategory={handleSelectCategory}
                    />

                    {/* Category Block 2: Church & World Humanitarian Missions */}
                    <CategorySection
                      title="Universal Church &amp; World Missions"
                      category="Church"
                      description="Diocesan assemblies, Caritas relief convoys, and global missionary frontlines."
                      articles={churchAndWorld}
                      onSelectArticle={handleSelectArticle}
                      onSelectCategory={handleSelectCategory}
                    />

                    {/* Category Block 3: Faith, Liturgy & Moral Analysis */}
                    <CategorySection
                      title="Faith, Scripture &amp; Moral Analysis"
                      category="Faith"
                      description="Theological commentaries, daily gospel reflections, sacred culture, and moral theology."
                      articles={faithAndCulture}
                      onSelectArticle={handleSelectArticle}
                      onSelectCategory={handleSelectCategory}
                    />
                  </>
                ) : (
                  /* Filtered Category Feed */
                  <div>
                    <div className="bg-white border border-[#E5E0D8] border-l-4 border-[#7B1113] p-6 mb-8 shadow-xs">
                      <span className="text-xs font-bold uppercase tracking-widest text-[#7B1113] block mb-1">
                        Editorial Desk Archive
                      </span>
                      <h2 className="font-serif-headline text-2xl sm:text-3xl font-extrabold text-[#1C1917]">
                        {activeCategory} Dispatches
                      </h2>
                      <p className="text-xs text-stone-500 mt-1 font-serif-body italic">
                        Showing {categoryArticles.length} international dispatches published under this label.
                      </p>
                    </div>

                    <div className="space-y-6">
                      {categoryArticles.map((article) => (
                        <article
                          key={article.id}
                          onClick={() => handleSelectArticle(article)}
                          className="bg-white border border-[#E5E0D8] p-5 flex flex-col sm:flex-row gap-5 hover:border-stone-400 hover:shadow-xs transition cursor-pointer group"
                        >
                          <div className="sm:w-56 aspect-16/10 flex-shrink-0 bg-stone-100 overflow-hidden rounded-xs">
                            <img
                              src={article.imageUrl}
                              alt={article.title}
                              className="w-full h-full object-cover group-hover:scale-104 transition duration-300"
                              loading="lazy"
                            />
                          </div>

                          <div className="flex flex-col justify-between flex-1">
                            <div>
                              <div className="flex items-center gap-2 text-[11px] text-stone-400 mb-1">
                                <span className="font-bold uppercase text-[#7B1113] bg-[#7B1113]/10 px-1.5 py-0.5 rounded">
                                  {article.category}
                                </span>
                                <span>•</span>
                                <span>{article.readTime}</span>
                              </div>

                              <h3 className="font-serif-headline text-lg font-bold text-stone-900 group-hover:text-[#7B1113] leading-snug mb-2 transition">
                                {article.title}
                              </h3>

                              <p className="font-serif-body text-xs text-stone-600 line-clamp-2 leading-relaxed">
                                {article.subtitle}
                              </p>
                            </div>

                            <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500 mt-3">
                              <span>By {article.author.name}</span>
                              <span className="text-[#C5A059] font-medium group-hover:underline">
                                Read Chronicle &rarr;
                              </span>
                            </div>
                          </div>
                        </article>
                      ))}
                    </div>
                  </div>
                )}

              </div>

              {/* Right / Editorial Sidebar (4 cols) */}
              <aside className="lg:col-span-4 space-y-8">
                
                {/* 1. Daily Liturgical Widget */}
                <LiturgicalWidget
                  liturgicalDay={CURRENT_LITURGICAL_DAY}
                  isOpenModal={liturgicalModalOpen}
                  onCloseModal={() => setLiturgicalModalOpen(false)}
                  onOpenModal={() => setLiturgicalModalOpen(true)}
                />

                {/* 2. Trending / Most Read Reports */}
                <div className="bg-white border border-[#E5E0D8] p-5 shadow-xs">
                  <div className="flex items-center gap-2 pb-3 border-b border-stone-200 mb-4">
                    <TrendingUp className="w-4 h-4 text-[#7B1113]" />
                    <h3 className="font-serif-headline text-sm font-bold uppercase tracking-wider text-[#7B1113]">
                      Most Read Dispatches
                    </h3>
                  </div>

                  <div className="space-y-4">
                    {popularArticles.map((art, idx) => (
                      <div
                        key={art.id}
                        onClick={() => handleSelectArticle(art)}
                        className="flex gap-3 group cursor-pointer pb-3 border-b border-stone-100 last:border-0 last:pb-0"
                      >
                        <span className="font-serif-headline text-2xl font-bold text-[#C5A059] w-6 flex-shrink-0">
                          0{idx + 1}
                        </span>
                        <div>
                          <span className="text-[10px] font-bold uppercase text-[#7B1113]">
                            {art.category}
                          </span>
                          <h4 className="font-serif-headline text-xs font-bold text-stone-800 group-hover:text-[#7B1113] leading-snug mt-0.5 line-clamp-2">
                            {art.title}
                          </h4>
                          <span className="text-[10px] text-stone-400 mt-1 block">
                            {art.readTime} • {art.views.toLocaleString()} reads
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. Vatican Radio Audio Stream Card */}
                <div className="bg-[#1C1917] text-white p-5 rounded-xs border-l-4 border-[#C5A059] shadow-sm">
                  <div className="flex items-center gap-2 mb-2 text-[#C5A059]">
                    <Radio className="w-4 h-4 text-red-400 animate-pulse" />
                    <span className="text-xs font-bold uppercase tracking-wider">
                      Vatican Radio Live Audio
                    </span>
                  </div>
                  <h4 className="font-serif-headline text-sm font-bold mb-2">
                    Daily English Shortwave &amp; Digital Broadcast
                  </h4>
                  <p className="text-xs text-stone-400 leading-relaxed mb-4">
                    Listen to Holy See diplomatic bulletins, the Pope&#39;s morning Angelus, and Gregorian chants streaming 24 hours.
                  </p>
                  <button
                    onClick={() => setAudioPlayerOpen(true)}
                    className="w-full py-2 bg-[#7B1113] hover:bg-[#9B1B1E] text-white text-xs font-bold uppercase tracking-wider rounded transition"
                  >
                    Open Live Player
                  </button>
                </div>

                {/* 4. Explore Labels / Categories Tag Cloud */}
                <div className="bg-white border border-[#E5E0D8] p-5 shadow-xs">
                  <div className="flex items-center gap-2 pb-3 border-b border-stone-200 mb-4">
                    <Tag className="w-4 h-4 text-[#7B1113]" />
                    <h3 className="font-serif-headline text-sm font-bold uppercase tracking-wider text-[#7B1113]">
                      Blogger Labels &amp; Desks
                    </h3>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {CATEGORIES.filter(c => c !== 'All').map((cat) => (
                      <button
                        key={cat}
                        onClick={() => handleSelectCategory(cat)}
                        className={`text-xs px-2.5 py-1 rounded transition border ${
                          activeCategory === cat
                            ? 'bg-[#7B1113] text-white border-[#7B1113] font-bold'
                            : 'bg-[#FAF9F6] text-stone-700 hover:bg-stone-200 border-stone-200 font-medium'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 5. In-page Newsletter Widget */}
                <div className="bg-[#FAF7F2] border border-[#E8D39E] p-5 rounded-xs">
                  <div className="flex items-center gap-2 text-[#7B1113] mb-2">
                    <Mail className="w-4 h-4" />
                    <h4 className="font-serif-headline text-sm font-bold uppercase tracking-wider">
                      Vatican Briefing
                    </h4>
                  </div>
                  <p className="text-xs text-stone-600 leading-relaxed mb-3">
                    Delivered each morning at 07:00 UTC with official Holy See statements and liturgical reflections.
                  </p>
                  <button
                    onClick={() => setNewsletterModalOpen(true)}
                    className="w-full py-2 bg-[#7B1113] hover:bg-[#580C0E] text-white text-xs font-bold uppercase tracking-wider rounded transition"
                  >
                    Subscribe Free
                  </button>
                </div>

              </aside>

            </div>

          </div>
        )}

      </main>

      {/* 5. Professional Footer */}
      <Footer
        onSelectCategory={handleSelectCategory}
        onOpenPolicyModal={handleOpenPolicy}
        onOpenAudio={() => setAudioPlayerOpen(true)}
        onOpenLiturgyModal={() => setLiturgicalModalOpen(true)}
        onOpenNewsletter={() => setNewsletterModalOpen(true)}
      />

      {/* 6. MODALS */}
      <SearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        articles={ARTICLES}
        onSelectArticle={handleSelectArticle}
      />

      <NewsletterModal
        isOpen={newsletterModalOpen}
        onClose={() => setNewsletterModalOpen(false)}
      />

      <EditorialPolicyModal
        isOpen={policyModalOpen}
        onClose={() => setPolicyModalOpen(false)}
        initialTab={policyModalTab}
      />

    </div>
  );
}
